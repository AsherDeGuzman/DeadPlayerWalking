extends Area2D
class_name HealingPickup

signal collected(amount: int)

const HEALING_FRACTION := 0.25


func _ready() -> void:
	body_entered.connect(_on_body_entered)
	queue_redraw()


func _on_body_entered(body: Node2D) -> void:
	var player := body as RunnerController
	if player == null:
		return

	var healing_amount := roundi(float(player.max_health) * HEALING_FRACTION)
	var restored_amount := player.restore_health(healing_amount)
	if restored_amount <= 0:
		return

	collected.emit(restored_amount)
	queue_free()


func _draw() -> void:
	draw_circle(Vector2(0, 3), 24.0, Color(0.06, 0.12, 0.12, 0.72))
	draw_circle(Vector2.ZERO, 19.0, Color("214b43"))
	draw_arc(Vector2.ZERO, 19.0, 0.0, TAU, 40, Color("85e0b3"), 3.0, true)
	draw_rect(Rect2(-4.0, -11.0, 8.0, 22.0), Color("c2f2c8"))
	draw_rect(Rect2(-11.0, -4.0, 22.0, 8.0), Color("c2f2c8"))
