extends Control

@onready var _run_manager: PersistentRunManager = $RunManager
@onready var _level: Level01Controller = $Level01

var _stage: Level01Controller
var _audio_manager: GameAudioManager
var _screen_layer: CanvasLayer
var _screen_root: Control
var _overlay_layer: CanvasLayer
var _is_between_runs := false
var _pause_layer: CanvasLayer
var _pause_root: Control
var _is_paused := false
var _settings_from_pause := false
var _last_outcome_text := ""
var _last_reward := 0
var _last_echo_recorded := false
var _return_to_menu_after_abandon := false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	process_mode = Node.PROCESS_MODE_ALWAYS
	_level.visible = false
	_audio_manager = get_node("/root/AudioManager") as GameAudioManager
	_audio_manager.set_music_volume(_run_manager.music_volume)
	_audio_manager.set_sfx_volume(_run_manager.sfx_volume)
	_run_manager.run_finished.connect(_on_run_finished)
	get_viewport().size_changed.connect(_refresh_responsive_layout)
	show_title_screen()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") and _stage != null and not _is_between_runs:
		_toggle_pause()
		get_viewport().set_input_as_handled()


func _draw() -> void:
	var view_size := get_viewport_rect().size
	draw_rect(Rect2(Vector2.ZERO, view_size), Color("10181c"))
	for x in range(0, int(view_size.x) + 60, 42):
		draw_line(Vector2(x, 0), Vector2(x, view_size.y), Color(0.61, 0.79, 0.7, 0.045), 1.0, true)
	for y in range(0, int(view_size.y) + 60, 42):
		draw_line(Vector2(0, y), Vector2(view_size.x, y), Color(0.61, 0.79, 0.7, 0.04), 1.0, true)
	draw_arc(Vector2(view_size.x * 0.72, 157), 106.0, 0.0, TAU, 72, Color(0.31, 0.69, 0.59, 0.16), 1.5, true)
	draw_arc(Vector2(view_size.x * 0.72, 157), 78.0, 0.0, TAU, 72, Color(0.31, 0.69, 0.59, 0.10), 1.0, true)
	draw_circle(Vector2(view_size.x * 0.72, 157), 25.0, Color(0.26, 0.55, 0.48, 0.18))
	draw_line(Vector2(0, 211), Vector2(view_size.x, 211), Color("4c635b"), 1.0, true)
	draw_line(Vector2(0, view_size.y - 115), Vector2(view_size.x, view_size.y - 115), Color(0.55, 0.73, 0.64, 0.15), 1.0, true)


func show_title_screen() -> void:
	_clear_stage()
	_clear_overlay()
	_clear_screen()
	_is_between_runs = false
	_create_screen_layer()

	_add_label(_screen_root, "TOKENS  /  DUNGEON LOG 01", Vector2(36, 82), Vector2(390, 25), 12, Color("86c9b0"))
	_add_label(_screen_root, "DEAD PLAYER\nWALKING", Vector2(34, 146), Vector2(480, 142), 50, Color("f0efe2"))
	_add_label(
		_screen_root,
		"THE PLAYER IMPROVES.\nTHEIR PAST REMAINS.",
		Vector2(38, 308),
		Vector2(440, 68),
		17,
		Color("a9c1b2")
	)

	var snapshot: Dictionary = _run_manager.get_progress_snapshot()
	var status := "%02d RUNS  /  %d SCRAP  /  %d ECHOES" % [
		int(snapshot["attempts"]),
		int(snapshot["points"]),
		int(snapshot["echo_count"]),
	]
	_add_label(_screen_root, status, Vector2(38, 397), Vector2(454, 26), 11, Color("d5b887"))

	_add_button(_screen_root, "ENTER THE DUNGEON", Vector2(40, 450), Vector2(460, 60), Color("30574c"), _begin_run)
	_add_button(_screen_root, "PERMANENT UPGRADES", Vector2(40, 522), Vector2(460, 54), Color("293c3d"), _show_workshop.bind(false, 0, false))
	_add_button(_screen_root, "SETTINGS", Vector2(40, 588), Vector2(460, 54), Color("293c3d"), _show_settings.bind(false))
	_add_button(_screen_root, "EXIT GAME", Vector2(40, 654), Vector2(460, 54), Color("67433a"), _exit_game)

	_add_label(_screen_root, "MOVE  WASD / ARROWS / TOUCH PAD", Vector2(42, 735), Vector2(455, 23), 11, Color("a8b8b0"))
	_add_label(_screen_root, "ATTACK  SPACE / J   SWITCH  Q   DASH  SHIFT / K   USE  E   PAUSE  ESC / P / II", Vector2(42, 763), Vector2(465, 34), 9, Color("a8b8b0"))
	_add_label(_screen_root, "FIXED ENCOUNTERS  ·  RUN DATA SAVED LOCALLY", Vector2(40, 820), Vector2(460, 35), 9, Color("748983"))


func _begin_run() -> void:
	_resume_run_audio()
	_clear_screen()
	_clear_overlay()
	_clear_pause_screen()
	_clear_stage()
	var run_number: int = _run_manager.begin_run()
	_audio_manager.play_sfx("echo")

	_stage = _level
	if not _stage.level_finished.is_connected(_on_level_finished):
		_stage.level_finished.connect(_on_level_finished)
	if not _stage.floor_cleared.is_connected(_on_stage_floor_cleared):
		_stage.floor_cleared.connect(_on_stage_floor_cleared)
	if not _stage.floor5_reveal_completed.is_connected(_run_manager.mark_floor5_reveal_seen):
		_stage.floor5_reveal_completed.connect(_run_manager.mark_floor5_reveal_seen)
	if not _stage.choice_requested.is_connected(_on_choice_requested):
		_stage.choice_requested.connect(_on_choice_requested)
	if not _stage.pause_requested.is_connected(_toggle_pause):
		_stage.pause_requested.connect(_toggle_pause)
	_stage.visible = true
	_stage.begin_run(
		_run_manager.get_player_stats(),
		_run_manager.get_echo_records(),
		run_number,
		int(_run_manager.get_progress_snapshot()["points"]),
		not _run_manager.has_seen_floor5_reveal()
	)


func _on_level_finished(completed: bool, record: Dictionary) -> void:
	_run_manager.finish_run(completed, record)


func _on_stage_floor_cleared(floor_number: int) -> void:
	var reward := _run_manager.award_floor_clear(floor_number)
	if reward <= 0 or _stage == null:
		return
	_stage.set_points_total(_run_manager.points)
	_stage.show_floor_reward(floor_number, reward)


func _on_run_finished(completed: bool, reward: int, total_points: int, recorded_echo: bool) -> void:
	_resume_run_audio()
	_last_outcome_text = "LEVEL COMPLETE" if completed else "RUN ENDED"
	_last_reward = reward
	_last_echo_recorded = recorded_echo
	if _stage != null:
		_stage.end_run()
		_stage.visible = false
		_stage = null
	_clear_overlay()
	if _return_to_menu_after_abandon:
		_return_to_menu_after_abandon = false
		show_title_screen()
	else:
		_show_workshop(true, reward, recorded_echo)


func _show_workshop(between_runs: bool, reward: int = 0, recorded_echo: bool = false) -> void:
	_clear_screen()
	_is_between_runs = between_runs
	_create_screen_layer()

	if between_runs:
		_add_label(_screen_root, "RUN SUMMARY  /  %02d" % int(_run_manager.get_progress_snapshot()["attempts"]), Vector2(36, 79), Vector2(445, 24), 12, Color("86c9b0"))
		var outcome_title := "FACILITY CLEARED" if _last_outcome_text == "LEVEL COMPLETE" else "SURVIVOR LOST"
		var outcome_detail := "OBJECTIVE REACHED  /  +%d SCRAP" % reward if _last_outcome_text == "LEVEL COMPLETE" else "HEALTH DEPLETED  /  +%d SCRAP" % reward
		var outcome_color := Color("b9e2c6") if _last_outcome_text == "LEVEL COMPLETE" else Color("eeaaa1")
		_add_label(_screen_root, outcome_title, Vector2(34, 124), Vector2(470, 58), 34, outcome_color)
		_add_label(_screen_root, outcome_detail, Vector2(38, 182), Vector2(465, 24), 11, Color("d5b887"))
		_add_label(
			_screen_root,
			"%s   ·   %d TOTAL SCRAP" % ["PREVIOUS SELF RECORDED" if recorded_echo else "NO NEW ECHO", int(_run_manager.points)],
			Vector2(38, 208),
			Vector2(465, 26),
			10,
			Color("b18c9a")
		)
	else:
		_add_label(_screen_root, "BETWEEN RUNS  /  WORKSHOP", Vector2(36, 105), Vector2(455, 24), 12, Color("86c9b0"))
		_add_label(_screen_root, "PERMANENT\nUPGRADES", Vector2(34, 151), Vector2(470, 104), 39, Color("f0efe2"))
		_add_label(_screen_root, "Spend scrap now. Every purchase carries into the next attempt.", Vector2(38, 268), Vector2(462, 44), 13, Color("a9c1b2"))

	var card_top := 247.0 if between_runs else 335.0
	var card := _make_panel(_screen_root, Vector2(30, card_top), Vector2(480, 452 if between_runs else 430))
	var card_content := Control.new()
	card_content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	card_content.mouse_filter = Control.MOUSE_FILTER_PASS
	card.add_child(card_content)

	var snapshot: Dictionary = _run_manager.get_progress_snapshot()
	var points := int(snapshot["points"])
	_add_label(card_content, "AVAILABLE SCRAP", Vector2(22, 16), Vector2(230, 20), 10, Color("89bda9"))
	_add_label(card_content, "%d" % points, Vector2(22, 40), Vector2(230, 48), 32, Color("f0d39a"))

	var upgrades: Dictionary = snapshot["upgrades"]
	var stats: Dictionary = _run_manager.get_player_stats()
	var rows := [
		{
			"id": "health",
			"detail": "+10 MAX HP  /  NOW %d" % int(stats["max_health"]),
		},
		{
			"id": "damage",
			"detail": "+2 BASE DAMAGE  /  NOW %d" % int(stats["attack_damage"]),
		},
		{
			"id": "speed",
			"detail": "+10 SPEED  /  NOW %d" % int(stats["move_speed"]),
		},
		{"id": "dungeon_edge", "detail": "+12%% SWORD DAMAGE  /  %.0f%% TOTAL" % (float(stats["sword_damage_multiplier"]) * 100.0)},
		{"id": "warden_crossbow", "detail": "+12%% BOLT DAMAGE  /  %.0f%% TOTAL" % (float(stats["crossbow_damage_multiplier"]) * 100.0)},
	]

	var row_y := 92.0 if between_runs else 82.0
	var row_step := 64.0 if between_runs else 62.0
	for row in rows:
		var upgrade_id: String = row["id"]
		var definition: Dictionary = PersistentRunManager.UPGRADE_DEFINITIONS[upgrade_id]
		var level := int(upgrades[upgrade_id])
		var maximum_level := int(PersistentRunManager.UPGRADE_MAX_LEVELS[upgrade_id])
		_add_label(
			card_content,
			"%s  /  %02d OF %02d" % [definition["name"], level, maximum_level],
			Vector2(22, row_y),
			Vector2(260, 20),
			10,
			Color("e3e7d8")
		)
		_add_label(card_content, row["detail"], Vector2(22, row_y + 20), Vector2(264, 20), 9, Color("95aaa0"))
		_add_label(card_content, str(definition["description"]), Vector2(22, row_y + 38), Vector2(264, 16), 8, Color("8ba198"))
		var price := int(_run_manager.get_upgrade_cost(upgrade_id))
		var maxed := _run_manager.is_upgrade_maxed(upgrade_id)
		var purchase := _add_button(
			card_content,
			"MAXED" if maxed else "%d  /  BUY" % price,
			Vector2(300, row_y + 1),
			Vector2(156, 40),
			Color("31544b"),
			_buy_upgrade.bind(upgrade_id)
		)
		purchase.disabled = maxed or points < price
		row_y += row_step

	if between_runs:
		var echoes := int(snapshot["echo_count"])
		_add_label(card_content, "HISTORY  /  %d OF 3 ECHO RECORDS" % echoes, Vector2(22, 416), Vector2(414, 24), 10, Color("b18c9a"))
		_add_button(_screen_root, "START THE NEXT RUN", Vector2(38, 817), Vector2(464, 66), Color("315b4d"), _begin_run)
	else:
		_add_label(card_content, "CHARACTER COSTS 20 / 25 / 20  ·  WEAPONS 30 SCRAP PER LEVEL", Vector2(22, 395), Vector2(436, 28), 8, Color("8ba198"))
		_add_button(_screen_root, "BACK TO THE FACILITY LOG", Vector2(38, 817), Vector2(464, 58), Color("293c3d"), show_title_screen)


func _buy_upgrade(upgrade_id: String) -> void:
	_run_manager.purchase_upgrade(upgrade_id)
	_show_workshop(_is_between_runs, _last_reward, _last_echo_recorded)


func _exit_game() -> void:
	get_tree().quit()


func _show_settings(paused: bool) -> void:
	_settings_from_pause = paused
	if paused:
		_show_pause_settings()
		return
	_clear_screen()
	_create_screen_layer()
	_add_label(_screen_root, "SETTINGS", Vector2(36, 124), Vector2(468, 60), 38, Color("f0efe2"), HORIZONTAL_ALIGNMENT_CENTER)
	_add_label(_screen_root, "Adjust sound levels for this device.", Vector2(42, 194), Vector2(456, 30), 13, Color("a9c1b2"), HORIZONTAL_ALIGNMENT_CENTER)
	_build_audio_settings(_screen_root, 286.0)
	_add_button(_screen_root, "SAVE AND RETURN", Vector2(38, 817), Vector2(464, 62), Color("315b4d"), _leave_settings)


func _build_audio_settings(parent: Control, top: float) -> void:
	_add_label(parent, "AMBIENCE", Vector2(48, top), Vector2(180, 28), 13, Color("e3e7d8"))
	_add_label(parent, "SOUND EFFECTS", Vector2(48, top + 92.0), Vector2(220, 28), 13, Color("e3e7d8"))
	var music_slider := _create_volume_slider(parent, "MusicVolume", Vector2(48, top + 34.0), _run_manager.music_volume)
	var effects_slider := _create_volume_slider(parent, "SfxVolume", Vector2(48, top + 126.0), _run_manager.sfx_volume)
	_add_label(parent, "Changes are saved on return.", Vector2(48, top + 184.0), Vector2(420, 26), 10, Color("8ba198"))
	music_slider.value_changed.connect(_on_music_volume_changed)
	effects_slider.value_changed.connect(_on_sfx_volume_changed)


func _create_volume_slider(
	parent: Control,
	slider_name: String,
	position: Vector2,
	value: float
) -> HSlider:
	var slider := HSlider.new()
	slider.name = slider_name
	slider.position = position
	slider.size = Vector2(390, 38)
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = value
	slider.tick_count = 11
	slider.ticks_on_borders = true
	parent.add_child(slider)
	return slider


func _on_music_volume_changed(value: float) -> void:
	_run_manager.set_audio_volumes(value, _run_manager.sfx_volume)
	_audio_manager.set_music_volume(value)


func _on_sfx_volume_changed(value: float) -> void:
	_run_manager.set_audio_volumes(_run_manager.music_volume, value)
	_audio_manager.set_sfx_volume(value)


func _leave_settings() -> void:
	_run_manager.save_settings()
	if _settings_from_pause:
		_show_pause_menu()
	else:
		show_title_screen()


func _on_choice_requested(choice_kind: String) -> void:
	if _stage == null:
		return
	_audio_manager.play_sfx("echo" if choice_kind == "previous_self" else "hazard")
	_stage.set_choice_paused(true)
	_clear_overlay()

	_overlay_layer = CanvasLayer.new()
	_overlay_layer.layer = 12
	add_child(_overlay_layer)
	var overlay := Control.new()
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	_overlay_layer.add_child(overlay)

	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.015, 0.025, 0.03, 0.86)
	shade.mouse_filter = Control.MOUSE_FILTER_STOP
	overlay.add_child(shade)

	var title := "CHOOSE YOUR ROUTE" if choice_kind == "route" else "A FAMILIAR SHAPE"
	var subheading := "The paths reconverge. The cost does not." if choice_kind == "route" else "This one learned from a run you did not survive."
	_add_label(overlay, title, Vector2(38, 322), Vector2(464, 62), 27, Color("f0efe2"), HORIZONTAL_ALIGNMENT_CENTER)
	_add_label(overlay, subheading, Vector2(48, 385), Vector2(444, 40), 13, Color("a9c1b2"), HORIZONTAL_ALIGNMENT_CENTER)

	if choice_kind == "route":
		_add_button(overlay, "SUPPLY ROUTE  /  LONGER, COVERED", Vector2(42, 476), Vector2(456, 68), Color("315348"), _select_route.bind("supply"))
		_add_label(overlay, "More cover. Scattered supplies. No active hazard.", Vector2(50, 544), Vector2(442, 32), 11, Color("98b4a2"), HORIZONTAL_ALIGNMENT_CENTER)
		_add_button(overlay, "HAZARDOUS SHORTCUT  /  FASTER", Vector2(42, 611), Vector2(456, 68), Color("67433a"), _select_route.bind("shortcut"))
		_add_label(overlay, "Open lane. One live conduit. Both routes rejoin ahead.", Vector2(50, 679), Vector2(442, 35), 11, Color("c5a18e"), HORIZONTAL_ALIGNMENT_CENTER)
	else:
		_add_button(overlay, "PRESS THE ATTACK  /  START ADVANTAGE", Vector2(42, 490), Vector2(456, 68), Color("67433a"), _select_previous_self.bind("strike"))
		_add_label(overlay, "Open with a hit. The echo begins wounded.", Vector2(50, 558), Vector2(442, 32), 11, Color("c5a18e"), HORIZONTAL_ALIGNMENT_CENTER)
		_add_button(overlay, "KEEP DISTANCE  /  REPOSITION", Vector2(42, 627), Vector2(456, 68), Color("315348"), _select_previous_self.bind("distance"))
		_add_label(overlay, "No free hit. Start across the room with space to move.", Vector2(50, 695), Vector2(442, 35), 11, Color("98b4a2"), HORIZONTAL_ALIGNMENT_CENTER)


func _select_route(route: String) -> void:
	_audio_manager.play_sfx("ui")
	if _stage != null:
		_stage.choose_route(route)
	_clear_overlay()


func _select_previous_self(response: String) -> void:
	_audio_manager.play_sfx("ui")
	if _stage != null:
		_stage.choose_previous_self(response)
	_clear_overlay()


func _create_screen_layer() -> void:
	_screen_layer = CanvasLayer.new()
	_screen_layer.layer = 5
	add_child(_screen_layer)
	_screen_root = Control.new()
	_screen_root.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_screen_root.size = Vector2(540.0, 960.0)
	_screen_root.mouse_filter = Control.MOUSE_FILTER_STOP
	_screen_layer.add_child(_screen_root)
	_fit_design_canvas(_screen_root)


func _clear_screen() -> void:
	if _screen_layer != null and is_instance_valid(_screen_layer):
		_screen_layer.queue_free()
	_screen_layer = null
	_screen_root = null


func _clear_overlay() -> void:
	if _overlay_layer != null and is_instance_valid(_overlay_layer):
		_overlay_layer.queue_free()
	_overlay_layer = null


func _toggle_pause() -> void:
	if _is_paused:
		_resume_run_audio()
		_clear_pause_screen()
		get_tree().paused = false
		_audio_manager.play_sfx("ui")
		return

	if _stage == null or _pause_layer != null:
		return

	_is_paused = true
	get_tree().paused = true
	_audio_manager.set_gameplay_paused(true)

	_pause_layer = CanvasLayer.new()
	_pause_layer.name = "PauseMenu"
	_pause_layer.layer = 20
	_pause_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(_pause_layer)

	_pause_root = Control.new()
	_pause_root.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	_pause_root.size = Vector2(540.0, 960.0)
	_pause_root.mouse_filter = Control.MOUSE_FILTER_STOP
	_pause_root.process_mode = Node.PROCESS_MODE_ALWAYS
	_pause_layer.add_child(_pause_root)
	_fit_design_canvas(_pause_root)
	_show_pause_menu()


func _show_pause_menu() -> void:
	if _pause_root == null or not is_instance_valid(_pause_root):
		return
	_clear_control_children(_pause_root)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.015, 0.025, 0.03, 0.88)
	shade.mouse_filter = Control.MOUSE_FILTER_STOP
	_pause_root.add_child(shade)
	_add_label(_pause_root, "RUN PAUSED", Vector2(35, 279), Vector2(470, 62), 37, Color("f0efe2"), HORIZONTAL_ALIGNMENT_CENTER)
	_add_label(_pause_root, "THE FACILITY IS WAITING.", Vector2(40, 342), Vector2(460, 28), 12, Color("a9c1b2"), HORIZONTAL_ALIGNMENT_CENTER)
	_add_button(_pause_root, "RESUME RUN  /  ESC", Vector2(42, 414), Vector2(456, 62), Color("315b4d"), _toggle_pause)
	_add_button(_pause_root, "SETTINGS", Vector2(42, 490), Vector2(456, 58), Color("293c3d"), _show_settings.bind(true))
	_add_button(_pause_root, "RETURN TO MAIN MENU", Vector2(42, 562), Vector2(456, 62), Color("67433a"), _show_abandon_confirmation)
	_add_label(
		_pause_root,
		"Leaving ends this attempt and records a defeat.",
		Vector2(50, 631),
		Vector2(442, 34),
		10,
		Color("c5a18e"),
		HORIZONTAL_ALIGNMENT_CENTER
	)


func _show_pause_settings() -> void:
	if _pause_root == null or not is_instance_valid(_pause_root):
		return
	_clear_control_children(_pause_root)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.015, 0.025, 0.03, 0.92)
	shade.mouse_filter = Control.MOUSE_FILTER_STOP
	_pause_root.add_child(shade)
	_add_label(_pause_root, "SETTINGS", Vector2(36, 255), Vector2(468, 60), 38, Color("f0efe2"), HORIZONTAL_ALIGNMENT_CENTER)
	_build_audio_settings(_pause_root, 366.0)
	_add_button(_pause_root, "BACK TO PAUSE MENU", Vector2(38, 690), Vector2(464, 62), Color("315b4d"), _leave_pause_settings)


func _leave_pause_settings() -> void:
	_run_manager.save_settings()
	_show_pause_menu()


func _show_abandon_confirmation() -> void:
	if _pause_root == null or not is_instance_valid(_pause_root):
		return
	var dialog := Control.new()
	dialog.name = "AbandonConfirmation"
	dialog.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dialog.mouse_filter = Control.MOUSE_FILTER_STOP
	dialog.process_mode = Node.PROCESS_MODE_ALWAYS
	dialog.z_index = 5
	_pause_root.add_child(dialog)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.01, 0.015, 0.02, 0.82)
	shade.mouse_filter = Control.MOUSE_FILTER_STOP
	dialog.add_child(shade)
	var panel := _make_panel(dialog, Vector2(30, 337), Vector2(480, 286))
	var content := Control.new()
	content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.add_child(content)
	_add_label(content, "LEAVE THIS RUN?", Vector2(20, 32), Vector2(440, 42), 22, Color("f0efe2"), HORIZONTAL_ALIGNMENT_CENTER)
	_add_label(
		content,
		"The run ends as a defeat. You receive 10 scrap and this survivor is saved as an echo.",
		Vector2(30, 86),
		Vector2(420, 64),
		12,
		Color("c5a18e"),
		HORIZONTAL_ALIGNMENT_CENTER
	)
	_add_button(content, "STAY IN THE DUNGEON", Vector2(25, 173), Vector2(202, 54), Color("315b4d"), _show_pause_menu)
	_add_button(content, "LEAVE RUN", Vector2(238, 173), Vector2(202, 54), Color("67433a"), _confirm_return_to_menu)


func _confirm_return_to_menu() -> void:
	_return_to_menu_after_abandon = true
	_abandon_run()


func _abandon_run() -> void:
	if _stage == null:
		return
	_resume_run_audio()
	_clear_pause_screen()
	get_tree().paused = false
	_stage.call("_finish_run", false)


func _resume_run_audio() -> void:
	if _audio_manager != null:
		_audio_manager.set_gameplay_paused(false)


func _clear_pause_screen() -> void:
	_is_paused = false
	if _pause_layer != null and is_instance_valid(_pause_layer):
		_pause_layer.queue_free()
	_pause_layer = null
	_pause_root = null


func _clear_stage() -> void:
	if _stage != null and is_instance_valid(_stage):
		_stage.end_run()
		_stage.visible = false
	_stage = null


func _add_label(
	parent: Control,
	text: String,
	position: Vector2,
	dimensions: Vector2,
	font_size: int,
	color: Color,
	alignment: int = HORIZONTAL_ALIGNMENT_LEFT
) -> Label:
	var label := Label.new()
	label.text = text
	label.position = position
	label.size = dimensions
	label.horizontal_alignment = alignment
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.mouse_filter = Control.MOUSE_FILTER_PASS
	parent.add_child(label)
	return label


func _clear_control_children(control: Control) -> void:
	for child in control.get_children():
		control.remove_child(child)
		child.queue_free()


func _refresh_responsive_layout() -> void:
	if _screen_root != null and is_instance_valid(_screen_root):
		_fit_design_canvas(_screen_root)
	if _pause_root != null and is_instance_valid(_pause_root):
		_fit_design_canvas(_pause_root)


func _fit_design_canvas(control: Control) -> void:
	var layout := get_design_canvas_layout_for_size(get_viewport_rect().size)
	control.scale = Vector2.ONE * float(layout["scale"])
	control.position = layout["offset"]


func get_design_canvas_layout_for_size(viewport_size: Vector2) -> Dictionary:
	if viewport_size.x <= 0.0 or viewport_size.y <= 0.0:
		return {"scale": 1.0, "offset": Vector2.ZERO}
	var scale_factor := minf(viewport_size.x / 540.0, viewport_size.y / 960.0)
	return {
		"scale": scale_factor,
		"offset": (viewport_size - Vector2(540.0, 960.0) * scale_factor) * 0.5,
	}


func _add_button(
	parent: Control,
	text: String,
	position: Vector2,
	dimensions: Vector2,
	color: Color,
	action: Callable
) -> Button:
	var button := Button.new()
	button.text = text
	button.position = position
	button.size = dimensions
	button.add_theme_font_size_override("font_size", 13)
	button.add_theme_color_override("font_color", Color("f0efe2"))
	button.add_theme_color_override("font_hover_color", Color("ffffff"))
	button.add_theme_color_override("font_disabled_color", Color("73817a"))
	button.add_theme_stylebox_override("normal", _button_style(color, Color("647f71")))
	button.add_theme_stylebox_override("hover", _button_style(color.lightened(0.12), Color("acd1b8")))
	button.add_theme_stylebox_override("pressed", _button_style(color.darkened(0.12), Color("a6c2ac")))
	button.add_theme_stylebox_override("disabled", _button_style(Color("202c2e"), Color("344244")))
	button.pressed.connect(func() -> void: _audio_manager.play_sfx("ui"))
	button.pressed.connect(action)
	parent.add_child(button)
	return button


func _make_panel(parent: Control, position: Vector2, dimensions: Vector2) -> PanelContainer:
	var panel := PanelContainer.new()
	panel.position = position
	panel.size = dimensions
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.075, 0.108, 0.116, 0.96)
	style.border_color = Color("465c55")
	style.set_border_width_all(1)
	style.corner_radius_top_left = 12
	style.corner_radius_top_right = 12
	style.corner_radius_bottom_left = 12
	style.corner_radius_bottom_right = 12
	panel.add_theme_stylebox_override("panel", style)
	parent.add_child(panel)
	return panel


func _button_style(background: Color, outline: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background
	style.border_color = outline
	style.set_border_width_all(1)
	style.corner_radius_top_left = 7
	style.corner_radius_top_right = 7
	style.corner_radius_bottom_left = 7
	style.corner_radius_bottom_right = 7
	style.content_margin_left = 10
	style.content_margin_right = 10
	return style
