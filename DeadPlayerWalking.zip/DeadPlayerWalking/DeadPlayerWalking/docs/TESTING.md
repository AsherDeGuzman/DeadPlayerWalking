# Testing and known issues

## Automated validation

Run the headless smoke test in a disposable copy as described in the README. It covers the actual main scene, UI/settings and pause flows, supported portrait viewport layouts, touch-control input, all ten floors and 38 rooms, fixed partial-heal pickups, floor and boss rewards, four deterministic obstacle layouts, room exit locks and transitions, combat tuning guardrails, player and echo weapons, snapshot persistence, both bosses, and final victory.

Room-layout checks verify that the full run uses all four layouts in sequence, visible cover has matching collision, boss rooms are open, and room-exit monitoring stays idle during combat. Combat guardrails check ordinary-enemy health/damage progression and the final boss's baseline health and attack damage.

The full smoke test passes in a disposable project copy on Godot 4.7.2. The runtime may still report a small number of ObjectDB instances at process shutdown; this warning has not caused a failing assertion but remains to be investigated.

## Known issues and remaining validation

- Viewport sizing and touch input are exercised headlessly at four portrait sizes, but the game has not been visually checked on a physical phone or tablet. A release candidate still needs a hands-on touch/UI check on target hardware.
- No Android export build or device performance/thermal benchmark has been run. Headless results do not establish frame-rate performance on low-end mobile hardware.
- Enemies and bosses use custom procedural drawings rather than dedicated sprite-sheet animation sets; the player and weapons use the included art assets.
- Projectile/effect pooling has not been added: current attack and effect rates are bounded, and no device profiling has shown a need for pooling.
- On this Windows setup, the Godot editor has intermittently exited with code `-1073741819` after asset import. A fresh import and separate runtime smoke test have subsequently completed successfully; verify both steps if the editor exit recurs.
