# Implementation Plan

## Design authority

`Dead_Player_Walking_GDD_Token.pdf` is the controlling design. Its core scope is a ten-floor mobile 2D dungeon, a fixed melee/ranged weapon pair, deterministic enemy rooms, partial healing, persistent floor/boss/death rewards, and previous-self enemies built only from final stat and weapon snapshots. Sections 8.4 and 8.5 are reserved for the scene-tree and signal-wiring plan based on the implemented project.

## Current project state

- Godot 4.7.1 project with mobile/desktop controls, player animations, health, character and weapon upgrades, save/load, two functional weapons, and an integration test.
- Dungeon foundation has ten floor resources and 38 deterministic, reusable combat rooms. Floors 1–4 use upper-dungeon themes; floors 5–10 use deep-dungeon themes. Room exits remain blocked until their enemies are defeated.
- The weapon milestone uses a timed melee `Area2D` hitbox and an independent collision-driven crossbow projectile.
- Death records store only character stats and weapon archetypes. Weaker previous selves spawn in configured rooms on later floors, pursue the current player, and use melee or collision-based ranged attacks according to the saved weapons.
- Floor 5's previous-self boss, the persisted first-arrival reveal, and Floor 10's final boss/victory gate are implemented with locked boss-room exits and telegraphed projectile attacks.
- Main menu, workshop/defeat/victory flows, pause and abandon confirmation, persisted audio settings, responsive HUD, and viewport-fitted menus are implemented. The workshop includes data-driven character and capped weapon damage upgrades.
- Normal rooms use four deterministic, visibly rendered obstacle layouts; boss arenas remain open. Exit monitoring is disabled during combat and enabled only after a room is cleared.
- Each floor has one fixed, authored partial-heal pickup in a regular room. It restores up to 25% of maximum health and never fills the player to full.
- Each cleared floor awards 30 scrap; Floor 5 and Floor 10 award additional boss bonuses of 60 and 100 scrap. Death awards 10 scrap.

## Confirmed GDD scope

- Preserve the current player controls, weapons, combat feedback, upgrades, save flow, and deterministic layout while expanding the run to ten floors.
- Provide configurable floor/room data, combat-room exits locked by live enemies, deterministic room-to-room progression, and fixed healing pickup locations. Do not randomize encounter or reward placement.
- Introduce Floor 5 and Floor 10 boss encounters and the first-arrival Floor 5 reveal.
- Replace movement/action replay with saved character-stat and weapon-archetype snapshots for previous selves.
- Keep permanent upgrades within the approved categories: maximum health, attack power, movement speed, Dungeon Edge, and Warden Crossbow.

## Milestones

1. **Project foundation:** already present and launch-tested.
2. **Combat foundation:** weapons, projectile collisions, enemy damage, feedback, and permanent weapon damage upgrades implemented.
3. **Dungeon foundation:** deterministic ten-floor, 38-room scene flow and enemy-locked exits implemented and validated.
4. **Progression:** replace action-history echoes with validated stat/weapon snapshots and later-floor combat echoes. Implemented.
5. **Bosses:** implement Floor 5 reveal/boss and Floor 10 final boss/victory. Implemented.
6. **UI/mobile:** implement settings, pause and confirmation flow, complete upgrade workshop, and responsive HUD/touch controls. Implemented.
7. **Content/polish:** retain the existing player/weapon art, animation sets, combat effects, and audio; add readable deterministic room layouts, authored partial healing, floor/boss rewards, combat-balance guardrails, and known-issue documentation. Implemented; manual device validation remains.

## Verification requirements

- Import and run the Godot headless integration check in a disposable project copy. Cover the full dungeon, weapon, progression, echo-combat, reveal, boss, victory, UI, mobile, room-layout, reward, and healing systems.
- Verify ten floors and configured room counts; each exit stays locked with active enemies and advances only after the room is cleared.
- Verify one fixed healing pickup per floor, partial restoration, and that full health does not consume it.
- Verify each floor awards 30 scrap exactly once, with +60 on Floor 5, +100 on Floor 10, and +10 on death.
- Preserve weapon hit windows, projectile collision/cleanup, controls, persistence, and run outcomes.
- Verify death records contain no action samples, and later-floor previous selves use weaker saved stats and weapon archetypes to attack the current player.
- Verify the first-arrival Floor 5 reveal, boss health/telegraphs, locked Floor 5/10 boss rooms, and victory directly after the final boss is defeated.
- Verify menu actions, saved settings, upgrade affordability and effects, pause/resume/abandon confirmation, touch attack and movement, and control placement across portrait viewport sizes.
- The expanded smoke test validates the complete ten-floor run, including healing and rewards.
- Milestone 7 added four layouts, visible/collidable cover, obstacle-free boss arenas, combat stat guardrails, and exit monitoring that is disabled during combat. Re-run the smoke test after healing and reward progression changes; check [docs/TESTING.md](TESTING.md) for remaining device-level validation.
- Re-run the integration suite after each milestone before marking that milestone complete.
