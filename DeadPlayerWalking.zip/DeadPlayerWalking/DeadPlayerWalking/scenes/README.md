# Scene Files

Open the `.tscn` files from this folder in Godot to inspect each saved scene tree. These files are organized into folders by their role in the game:

```text
scenes/
|-- core/
|   |-- main.tscn
|   `-- level01.tscn
|-- actors/
|   |-- player.tscn
|   |-- basic_enemy.tscn
|   `-- previous_self.tscn
|-- ui/
|   `-- hud.tscn
|-- dungeon/
|   |-- room.tscn
|   |-- boss.tscn
|   `-- healing_pickup.tscn
`-- projectiles/
    `-- crossbow_projectile.tscn
```

## Which scene to open

- `core/main.tscn` is the project entry scene. Its saved tree contains `Main (Control)`, `RunManager (Node)`, and an instance of `Level01 (Node2D)`.
- `core/level01.tscn` contains `Rooms (Node2D)` with a room instance, an instance of `Player (CharacterBody2D)`, and an instance of `HUD (CanvasLayer)`.
- Expand `Level01 > Player` to inspect the player body and melee collision shapes.
- Expand `Level01 > Rooms > DungeonRoom > WorldGeometry` to inspect the room boundary, exit gate, and all six obstacle collision nodes. Expand `ExitTrigger` and `HealingPickup` to inspect their area collision shapes.
- `actors/player.tscn` shows the player body, sprites, melee hitbox, effects, and camera.
- `ui/hud.tscn` is the HUD CanvasLayer. The HUD script creates its `Screen` control and its interface nodes at runtime.
- `dungeon/room.tscn` is the reusable room root. The room script adds geometry, enemies, healing pickups, and the exit when the room runs.

The project starts at `core/main.tscn`. `Level01` is saved as a child of `Main`, but is not visible in-game until a run begins. The room's six obstacle collision nodes are saved in the room scene and enabled as required by the deterministic layout. Enemies and projectiles are spawned at runtime and can be inspected in Godot's **Remote** scene tree while the game is running. Open `actors/basic_enemy.tscn`, `actors/previous_self.tscn`, and `dungeon/boss.tscn` to inspect each actor's own collision shape.
