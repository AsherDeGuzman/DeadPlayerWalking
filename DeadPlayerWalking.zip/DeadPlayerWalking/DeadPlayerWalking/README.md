# Dead Player Walking

A self-contained, portrait-first 2D action roguelike built for **Godot 4.7.1-stable (Windows x64)**. The project includes the player sprite sheets it uses and has no add-ons to install.

## Open and play

1. In Godot 4.7.1, choose **Import**.
2. Select this folder's `project.godot` file.
3. Open the project and press **F6** or **F5**.

The project is configured for a 540 × 960 portrait viewport and the GL Compatibility renderer. The same project also runs on desktop for testing.

## Scene files in Godot

In the Godot **FileSystem** dock, expand `scenes` and open each `.tscn` file to inspect that scene's tree. Scenes are grouped by purpose:

```text
scenes/
|-- core/        main.tscn and level01.tscn
|-- actors/      player.tscn, basic_enemy.tscn, previous_self.tscn
|-- ui/          hud.tscn
|-- dungeon/     room.tscn, boss.tscn, healing_pickup.tscn
`-- projectiles/ crossbow_projectile.tscn
```

`main.tscn` contains `Main > RunManager` and an instanced `Level01` scene, so the gameplay hierarchy is visible in the editor even while the title menu is active. The level includes its player, HUD, a room instance, and authored collision nodes. Enemies and projectiles are still created at runtime. See [`scenes/README.md`](scenes/README.md) for a scene-by-scene guide.

## Controls

| Action | Keyboard | Touch |
|---|---|---|
| Move | WASD or arrow keys | Virtual stick at lower left |
| Attack with equipped weapon | Space or J | Attack button at lower right |
| Switch weapon | Q | SWAP button above DASH |
| Dash / dodge | Shift or K | DASH button at lower right |
| Use an unlocked exit | E or Enter | USE button at lower right |
| Pause / resume | Escape or P | II button at the top-right |

Movement and actions can be used together. The Dungeon Edge only damages enemies during its active swing frames. The Warden Crossbow fires a collision-based bolt in the player's facing direction; a hit damages one enemy and shows an impact. Each weapon has its own cooldown. The dash grants a brief window of invulnerability and has a short cooldown.

The main character uses the included idle, walk, melee attack, ranged attack, hurt, dodge, and death sprite animations. Equipped weapon art and attack effects use the matching artwork in `assets/weapons/`. Weapon behavior is configurable in `resources/weapons/`; the standalone crossbow projectile scene owns its movement, collision, damage, impact, and cleanup.

An original procedural ambient track plays during the run, with generated sound cues for combat, dodging, damage, exits, echoes, UI actions, and win/lose outcomes. Audio pauses with the pause menu.

The title menu includes Settings and Exit. Settings control and persist ambience/effects volume. The pause menu can resume, open settings, or return to the title after confirming that the attempt will be recorded as a defeat. HUD and touch controls scale to portrait viewports; the virtual joystick, attack, swap, dash, and contextual exit controls are checked at multiple viewport sizes.

## Dungeon progression

The run now spans ten configurable floors and 38 deterministic combat rooms. Floors 1–4 use the upper-dungeon palette; floors 5–10 use deep-dungeon palettes. Room counts and enemy pressure rise with depth. Normal rooms cycle through four deterministic obstacle layouts with visible, collidable cover; boss arenas stay open. Each floor has one authored, non-random healing pickup in a regular combat room. It restores up to 25% of maximum health without filling the player to full. Each room is a reusable scene: enemies lock the exit, clearing all enemies unlocks it, and entering the exit transitions to the next connected room or floor.

Deaths save a compact snapshot of the character's stats and weapon archetypes, not a replay of recorded actions. Weaker previous selves appear in selected later-floor rooms and fight with melee and/or crossbow attacks. Floor 5 introduces the previous-self boss with a one-time saved reveal; Floor 10 ends with the Hollow Warden, a telegraphed multi-bolt final boss, and victory immediately on defeat. Boss rooms have dedicated encounter states and health bars, and their exits stay locked until the boss is defeated. The controlling design is [Dead_Player_Walking_GDD_Token.pdf](docs/Dead_Player_Walking_GDD_Token.pdf).

Each cleared floor awards 30 scrap; the Floor 5 boss adds 60 and the Floor 10 boss adds 100. Death awards 10 scrap. Permanent character upgrades cost 20 scrap for +10 maximum HP, 25 for +2 base attack damage, and 20 for +10 movement speed. Dungeon Edge and Warden Crossbow upgrades cost 30 scrap per level, add 12% damage, and cap at level 5.

## Save data and validation

Progress is written to Godot's per-user `user://dead_player_walking.cfg` file. It is separate from the project folder.

All game sounds are original PCM samples synthesized for this project. The player animation sheets are in `assets/player/`.

The supplied GDD is included at `docs/Dead_Player_Walking_GDD_Token.pdf`. Its Sections 8.4 and 8.5 are intentionally left for the scene-tree and signal-wiring plan based on this implementation.

To run the included headless integration check without touching your normal save, first copy the project to a temporary folder and give the test copy a different application name:

```powershell
$testProject = Join-Path $env:TEMP "DeadPlayerWalking-SmokeTest"
$projectName = "Dead Player Walking Smoke Test " + [guid]::NewGuid().ToString("N")
New-Item -ItemType Directory -Force -Path $testProject | Out-Null
Copy-Item -Path ".\project.godot", ".\icon.svg", ".\scenes", ".\scripts", ".\assets", ".\resources", ".\tests" -Destination $testProject -Recurse -Force
$projectFile = Join-Path $testProject "project.godot"
$config = (Get-Content $projectFile -Raw).Replace('config/name="Dead Player Walking"', ('config/name="' + $projectName + '"'))
Set-Content -Path $projectFile -Value $config -NoNewline
$godot = "C:\path\to\Godot_v4.7.1-stable_win64_console.exe"
& $godot --headless --editor --path $testProject --quit
if ($LASTEXITCODE -eq 0) { & $godot --headless --path $testProject --script "res://tests/smoke_test.gd" }
$testExitCode = $LASTEXITCODE
$testSave = Join-Path $env:APPDATA ("Godot\app_userdata\" + $projectName)
if (Test-Path -LiteralPath $testSave) { Remove-Item -LiteralPath $testSave -Recurse -Force }
Remove-Item -LiteralPath $testProject -Recurse -Force
exit $testExitCode
```

The test exercises the actual main scene, title/settings/workshop/pause flows, saved audio levels, upgrade affordability, responsive menu/touch-control layouts, virtual joystick and touch attack, all ten floor definitions, fixed partial healing pickups, deterministic room layouts, locked and cleared exits, room transitions, floor and boss rewards, combat tuning guardrails, timed melee hitbox, collision-based player and echo projectiles, snapshot-only death records, later-floor echo combat, the Floor 5 reveal and boss telegraph, both locked boss encounters, final-boss victory, and permanent upgrades. See [docs/TESTING.md](docs/TESTING.md) for known limitations and remaining device-level validation.
