extends SceneTree

var _failed := false


func _initialize() -> void:
	call_deferred("_run_tests")


func _run_tests() -> void:
	var main_scene := load("res://scenes/main.tscn") as PackedScene
	_expect(main_scene != null, "The main scene should load.")
	if main_scene == null:
		quit(1)
		return

	var main := main_scene.instantiate() as Control
	root.add_child(main)
	await process_frame

	var audio_manager := root.get_node("AudioManager") as GameAudioManager
	var manager := main.get_node("RunManager") as PersistentRunManager
	_expect(manager != null, "The persistent run manager should be present.")
	var main_menu_settings := _find_button(main, "SETTINGS")
	_expect(main_menu_settings != null, "The main menu should expose Settings.")
	_expect(_find_button(main, "EXIT GAME") != null, "The main menu should expose Exit.")
	if main_menu_settings != null:
		main_menu_settings.emit_signal("pressed")
		await process_frame
		var main_screen := main.get("_screen_root") as Control
		var music_slider := main_screen.get_node_or_null("MusicVolume") as HSlider
		var effects_slider := main_screen.get_node_or_null("SfxVolume") as HSlider
		_expect(music_slider != null and effects_slider != null, "Settings should expose music and effect volume controls.")
		if music_slider != null and effects_slider != null:
			music_slider.value = 0.65
			effects_slider.value = 0.75
			_expect(is_equal_approx(audio_manager.music_volume, 0.65), "The music slider should update live audio.")
			_expect(is_equal_approx(audio_manager.sfx_volume, 0.75), "The effects slider should update live audio.")
			main.call("_leave_settings")
			_expect(is_equal_approx(manager.music_volume, 0.65), "Settings should persist music volume.")
			_expect(is_equal_approx(manager.sfx_volume, 0.75), "Settings should persist effects volume.")
			var settings_save := ConfigFile.new()
			_expect(settings_save.load(PersistentRunManager.SAVE_PATH) == OK, "Audio settings should be written to the save file.")
			_expect(is_equal_approx(float(settings_save.get_value("settings", "music_volume", 0.0)), 0.65), "The saved music level should match the slider.")
			_expect(is_equal_approx(float(settings_save.get_value("settings", "sfx_volume", 0.0)), 0.75), "The saved effects level should match the slider.")
			manager.set_audio_volumes(1.0, 1.0)
			manager.save_settings()
			audio_manager.set_music_volume(1.0)
			audio_manager.set_sfx_volume(1.0)
	main.call("_show_workshop", false, 0, false)
	await process_frame
	var workshop_screen := main.get("_screen_root") as Control
	var unaffordable_weapon_purchase := _find_button(workshop_screen, "30  /  BUY")
	_expect(unaffordable_weapon_purchase != null and unaffordable_weapon_purchase.disabled, "Weapon upgrades should be visible but unaffordable without currency.")
	_expect(_contains_label(workshop_screen, "+12% sword damage"), "Weapon upgrades should display their descriptions.")
	_expect(_contains_label(workshop_screen, "+12% bolt damage"), "Both weapon upgrade descriptions should be displayed.")
	main.call("show_title_screen")
	var canvas_sizes := [Vector2(540.0, 960.0), Vector2(420.0, 900.0), Vector2(360.0, 640.0), Vector2(800.0, 1280.0)]
	for canvas_size in canvas_sizes:
		var canvas_layout: Dictionary = main.call("get_design_canvas_layout_for_size", canvas_size)
		var fitted_size := Vector2(540.0, 960.0) * float(canvas_layout["scale"])
		var canvas_offset: Vector2 = canvas_layout["offset"]
		_expect(
			canvas_offset.x >= 0.0
			and canvas_offset.y >= 0.0
			and canvas_offset.x + fitted_size.x <= canvas_size.x + 0.01
			and canvas_offset.y + fitted_size.y <= canvas_size.y + 0.01,
			"Menu and pause canvases should fit supported viewport sizes."
		)

	var sword_config := load("res://resources/weapons/dungeon_edge.tres") as WeaponConfig
	var crossbow_config := load("res://resources/weapons/warden_crossbow.tres") as WeaponConfig
	_expect(sword_config != null and sword_config.projectile_scene == null, "The sword configuration should load.")
	_expect(crossbow_config != null and crossbow_config.projectile_scene != null, "The crossbow projectile configuration should load.")
	_expect(audio_manager._music_player.stream == audio_manager._music_stream, "Facility ambience should be assigned.")
	_expect(audio_manager._music_stream.loop_mode == AudioStreamWAV.LOOP_FORWARD, "Facility ambience should loop.")
	_expect(audio_manager._sfx_players.size() == GameAudioManager.SFX_CHANNEL_COUNT, "The sound pool should initialize.")
	_expect(InputMap.has_action("pause"), "Pause should be a named InputMap action.")
	_expect(InputMap.has_action("switch_weapon"), "Weapon switching should be a named InputMap action.")

	var floor_definitions := Level01Controller.FLOOR_DEFINITIONS
	var combat_balance_probe := FacilityEnemy.new()
	combat_balance_probe.configure_for_floor(1)
	_expect(combat_balance_probe.max_health == 42, "Floor one enemy health should match the baseline tuning.")
	_expect(combat_balance_probe.attack_damage == 8, "Floor one enemy damage should match the baseline tuning.")
	combat_balance_probe.configure_for_floor(10)
	_expect(combat_balance_probe.max_health == 70, "Floor ten enemy health should rise gradually to the tested cap.")
	_expect(combat_balance_probe.attack_damage == 12, "Floor ten enemy damage should stay near one-eighth of base player health.")
	_expect(is_equal_approx(combat_balance_probe.movement_speed, 119.0), "Enemy speed should rise gradually without exceeding the tested cap.")
	combat_balance_probe.free()
	_expect(floor_definitions.size() == 10, "The dungeon should define ten floors.")
	var total_rooms := 0
	var previous_room_count := 0
	for floor_index in floor_definitions.size():
		var definition := floor_definitions[floor_index] as FloorDefinition
		_expect(definition.floor_number == floor_index + 1, "Floor definitions should be ordered.")
		_expect(definition.room_count >= previous_room_count, "Room counts should not decrease on deeper floors.")
		_expect(definition.base_enemy_count >= 1, "Each floor should have combat encounters.")
		previous_room_count = definition.room_count
		total_rooms += definition.room_count
	_expect(total_rooms == 38, "The ten floors should contain the configured 38 deterministic rooms.")
	_expect((floor_definitions[3] as FloorDefinition).floor_name == "Upper Dungeon", "Floors one through four should use the upper theme.")
	_expect((floor_definitions[4] as FloorDefinition).floor_name == "Deep Dungeon", "Floor five should begin the deep theme.")
	_expect((floor_definitions[4] as FloorDefinition).boss_id == &"previous_self", "Floor five should be configured for its previous-self boss.")
	_expect((floor_definitions[9] as FloorDefinition).boss_id == &"hollow_warden", "Floor ten should be configured for its final boss.")

	_expect(manager.get_player_stats() == {
		"max_health": 100,
		"attack_damage": 10,
		"move_speed": 200.0,
		"sword_damage_multiplier": 1.0,
		"crossbow_damage_multiplier": 1.0,
	}, "A fresh save should use its default starting stats.")

	main.call("_begin_run")
	await process_frame
	var stage := main.get("_stage") as Level01Controller
	_expect(stage != null, "Starting a run should load the dungeon.")
	if stage == null:
		quit(1)
		return

	_expect(stage.get_current_floor_number() == 1, "A new run should begin on floor one.")
	_expect(stage.get_current_room_number() == 1, "A new run should begin in the first room.")
	_expect(not stage.is_processing(), "Exit monitoring should stay idle during active combat.")
	var touch_pause := stage.get_node("HUD/Screen/PauseButton") as Button
	_expect(touch_pause != null, "The HUD should have an on-screen pause button.")
	touch_pause.emit_signal("pressed")
	_expect(paused and audio_manager.gameplay_paused, "Pause should stop both gameplay and gameplay audio.")
	main.call("_show_settings", true)
	var pause_root := main.get("_pause_root") as Control
	var pause_music_slider := pause_root.get_node_or_null("MusicVolume") as HSlider
	_expect(pause_music_slider != null, "The pause menu should offer Settings.")
	if pause_music_slider != null:
		pause_music_slider.value = 0.55
		main.call("_leave_pause_settings")
		_expect(is_equal_approx(audio_manager.music_volume, 0.55), "Pause settings should update music volume.")
	_expect(_find_button(pause_root, "RETURN TO MAIN MENU") != null, "The pause menu should offer a return action.")
	main.call("_show_abandon_confirmation")
	_expect(pause_root.get_node_or_null("AbandonConfirmation") != null, "Returning to the main menu should require confirmation.")
	main.call("_show_pause_menu")
	main.call("_toggle_pause")
	_expect(not paused and not audio_manager.gameplay_paused, "Resume should restore gameplay and audio.")
	manager.set_audio_volumes(1.0, 1.0)
	manager.save_settings()
	audio_manager.set_music_volume(1.0)
	audio_manager.set_sfx_volume(1.0)

	var player := stage.get_node("Player") as RunnerController
	var player_sprite := player.get_node("AnimatedSprite2D") as AnimatedSprite2D
	var touch_controls := stage.get_node("HUD/Screen/TouchControls") as TouchControls
	var hud := stage.get_node("HUD") as CanvasLayer
	var layout_sizes := [Vector2(540.0, 960.0), Vector2(420.0, 900.0), Vector2(360.0, 640.0), Vector2(800.0, 1280.0)]
	for layout_size in layout_sizes:
		var centers: Dictionary = touch_controls.get_action_centers_for_size(layout_size)
		for control_center in centers.values():
			var point: Vector2 = control_center
			_expect(
				point.x >= 0.0 and point.x <= layout_size.x and point.y >= 0.0 and point.y <= layout_size.y,
				"Touch controls should remain on-screen at supported viewport sizes."
			)
	_expect(hud._health_track.size.x > 0.0, "The HUD should size its health bar from the viewport.")
	var joystick_center: Vector2 = touch_controls.get_action_centers()["joystick"]
	touch_controls.call("_handle_press", joystick_center + Vector2(50.0, 0.0), -3)
	_expect(touch_controls.get_movement_vector().x > 0.7, "The lower-left virtual joystick should return directional movement.")
	touch_controls.call("_handle_release", -3)
	_expect(touch_controls.get_movement_vector() == Vector2.ZERO, "Releasing the virtual joystick should clear movement.")
	_expect(player.get_current_weapon_id() == &"dungeon_edge", "The sword should be equipped at run start.")
	_expect((player.get_node("SwordSprite") as Sprite2D).visible, "The equipped sword should be visible.")
	_expect(not (player.get_node("CrossbowSprite") as Sprite2D).visible, "The unequipped crossbow should be hidden.")
	_expect(player.get_node_or_null("MeleeHitbox") is Area2D, "The player should have a dedicated melee hitbox.")
	_expect(player_sprite.sprite_frames.get_frame_count("idle") == 4, "The idle sheet should have four frames.")
	_expect(player_sprite.sprite_frames.get_frame_count("walk") == 8, "The walk sheet should have eight frames.")
	_expect(player_sprite.sprite_frames.get_frame_count("melee_attack") == 6, "The melee sheet should have six frames.")
	_expect(player_sprite.sprite_frames.get_frame_count("ranged_attack") == 6, "The ranged sheet should have six frames.")
	_expect(player_sprite.sprite_frames.get_frame_count("hurt") == 3, "The hurt sheet should have three frames.")
	_expect(player_sprite.sprite_frames.get_frame_count("death") == 6, "The death sheet should have six frames.")
	_expect(player_sprite.sprite_frames.get_frame_count("dodge") == 4, "The dodge sheet should have four frames.")

	var room := stage.get_current_room()
	var enemies := room.get_node("Enemies")
	_expect(room.get_layout_index() == 0, "The first deterministic room should use the open layout.")
	_expect(room.get_obstacle_count() == 0, "The open room layout should not add obstacles.")
	_expect(enemies.get_child_count() == 2, "The first room should spawn its configured enemies.")
	_expect(not room.is_exit_unlocked(), "A room exit should stay locked while enemies remain.")
	var first_enemy := enemies.get_child(0) as FacilityEnemy
	player.position = first_enemy.position + Vector2(0, -42)
	var enemy_health := first_enemy.health
	var attack_center: Vector2 = touch_controls.get_action_centers()["attack"]
	touch_controls.call("_handle_press", attack_center, -3)
	touch_controls.call("_handle_release", -3)
	_expect(player_sprite.animation == "melee_attack", "The sword attack should use its matching animation.")
	_expect((player.get_node("SlashEffect") as Sprite2D).visible, "A sword swing should show its slash effect.")
	_expect(first_enemy.health == enemy_health, "The sword should not damage before its active attack frames.")
	for _frame in 3:
		await physics_frame
	_expect(first_enemy.health == enemy_health, "The sword should remain harmless during windup.")
	for _frame in 15:
		await physics_frame
	_expect(first_enemy.health == enemy_health - player.attack_damage, "The active sword hitbox should damage an enemy.")
	_expect(not (player.get_node("MeleeHitbox") as Area2D).monitoring, "The sword hitbox should close after the attack window.")

	player.position = Vector2(270.0, 76.0)
	await physics_frame
	_expect(stage.get_current_room_number() == 1, "An uncleared room must not allow its exit to advance.")
	player.position = Vector2(270.0, 870.0)
	touch_controls.call("_handle_press", touch_controls.call("_weapon_switch_center"), -2)
	_expect(player.get_current_weapon_id() == &"warden_crossbow", "The touch swap control should equip the crossbow.")
	_expect((player.get_node("CrossbowSprite") as Sprite2D).visible, "The equipped crossbow should be visible.")
	_expect(not (player.get_node("SwordSprite") as Sprite2D).visible, "Switching should hide the sword.")
	_expect(touch_controls._attack_label == "BOLT", "The touch attack button should show the equipped weapon.")
	_expect(_contains_label(stage, "WEAPON: WARDEN CROSSBOW"), "The HUD should show the selected weapon.")

	player.position = first_enemy.position + Vector2(0, -150)
	enemy_health = first_enemy.health
	player.request_attack()
	_expect(player_sprite.animation == "ranged_attack", "The crossbow shot should use its matching animation.")
	_expect(first_enemy.health == enemy_health, "A bolt should not damage before colliding.")
	var projectile := stage.get_node_or_null("CrossbowProjectile") as CrossbowProjectile
	_expect(projectile != null, "A crossbow attack should instantiate its independent projectile scene.")
	for _frame in 15:
		await physics_frame
	_expect(first_enemy.health == enemy_health - player.attack_damage, "The bolt should damage its target on collision.")
	_expect(is_instance_valid(projectile) and projectile._impact_sprite.visible, "A collision should display the projectile impact.")
	touch_controls.call("_handle_release", -2)
	touch_controls.call("_handle_press", touch_controls.call("_weapon_switch_center"), -2)
	_expect(player.get_current_weapon_id() == &"dungeon_edge", "The touch control should switch back to the sword.")
	_expect(float(player._weapon_cooldowns[&"warden_crossbow"]) > 0.0, "The crossbow should retain its independent cooldown.")
	player.request_attack()
	_expect(player_sprite.animation == "melee_attack", "The sword should remain usable while the crossbow cools down.")
	touch_controls.call("_handle_release", -2)
	for _frame in 15:
		await physics_frame
	_expect(not is_instance_valid(projectile), "The bolt should clean itself up after impact.")
	_expect(touch_controls._pressed_action.is_empty(), "Releasing the swap control should clear its pressed state.")
	_expect(touch_controls._attack_label == "STRIKE", "The attack button should update after switching back.")

	player.position = Vector2(270.0, 76.0)
	for enemy in enemies.get_children():
		(enemy as FacilityEnemy).take_damage(10000)
	_expect(room.is_exit_unlocked(), "Defeating every enemy should unlock the room exit.")
	_expect(room.get_remaining_enemy_count() == 0, "The room should track zero remaining enemies.")
	await physics_frame
	await process_frame
	_expect(stage.get_current_room_number() == 2, "Unlocking the exit while waiting there should transition automatically.")
	_expect(stage.get_current_floor_number() == 1, "Room transitions should remain on the current floor until its last room.")
	room = stage.get_current_room()
	_expect(room.get_layout_index() == 1, "The next room should use the next deterministic layout.")
	_expect(room.get_obstacle_count() == 2, "The staggered layout should add visible, collidable cover.")

	player._invulnerability_time = 0.0
	player.take_damage(10000)
	_expect(player_sprite.animation == "death", "Lethal damage should play the death animation.")
	await player.player_died
	await process_frame
	_expect(manager.points == 10, "Death should grant exactly ten scrap.")
	var echo_records := manager.get_echo_records()
	_expect(echo_records.size() == 1, "Death should store one character snapshot.")
	var saved_snapshot: Dictionary = echo_records[0] if not echo_records.is_empty() else {}
	_expect(
		saved_snapshot.has("max_health")
		and saved_snapshot.has("attack_damage")
		and saved_snapshot.has("move_speed"),
		"A death snapshot should preserve character combat stats."
	)
	_expect(
		saved_snapshot.get("weapon_archetypes", []) == ["dungeon_edge", "warden_crossbow"],
		"A death snapshot should preserve its weapon archetypes."
	)
	_expect(not saved_snapshot.has("samples"), "A death snapshot should not contain replayed actions.")
	_expect(main.get("_stage") == null, "A death outcome should return to the workshop.")
	_expect(_contains_label(main, "SURVIVOR LOST"), "The death screen should report the run outcome.")
	_expect(_find_button(main, "START THE NEXT RUN") != null, "The defeat flow should offer a restart/continue action.")
	_expect(_contains_label(main, "DUNGEON EDGE"), "The defeat workshop should expose weapon upgrades.")

	main.call("_begin_run")
	await process_frame
	stage = main.get("_stage") as Level01Controller
	_expect(stage != null, "A second run should start.")
	if stage == null:
		quit(1)
		return

	var traversed_rooms := 0
	var room_layout_mask := 0
	var room_layout_seed := 0
	var echo_combat_verified := false
	var floor5_boss_verified := false
	var final_boss_verified := false
	var completed_by_final_boss := false
	for floor_index in floor_definitions.size():
		var floor_definition := floor_definitions[floor_index] as FloorDefinition
		for room_index in floor_definition.room_count:
			room = stage.get_current_room()
			_expect(stage.get_current_floor_number() == floor_index + 1, "Floor transitions should advance in order.")
			_expect(stage.get_current_room_number() == room_index + 1, "Room transitions should advance in order.")
			var room_enemies := room.get_node("Enemies")
			if room.is_boss_encounter():
				_expect(room.get_layout_index() == -1, "Boss arenas should remain open and obstacle-free.")
				_expect(room.get_obstacle_count() == 0, "Boss arenas should not contain cover obstacles.")
				_expect(room.get_encounter_state() == DungeonRoom.EncounterState.BOSS, "Boss rooms should enter their dedicated encounter state.")
				_expect(not room.is_exit_unlocked(), "A boss room exit must remain locked until its boss is defeated.")
				_expect(stage.get_node("HUD").call("is_boss_health_visible"), "Boss encounters should display the boss health bar.")
				var boss := room_enemies.get_child(0) as DungeonBoss
				_expect(boss != null, "A configured boss room should spawn a DungeonBoss.")
				if boss != null and floor_index == 4:
					_expect(boss.boss_id == &"previous_self", "Floor five should introduce the previous-self boss.")
					_expect(not player.controls_enabled, "The Floor five reveal should disable player controls.")
					_expect(_contains_label(stage, "A PAST SELF STANDS IN YOUR WAY"), "The Floor five reveal should identify the boss.")
					await create_timer(1.3).timeout
					_expect(player.controls_enabled, "The Floor five reveal should restore player controls.")
					_expect(manager.has_seen_floor5_reveal(), "The completed first-arrival reveal should persist.")
					_expect(not _contains_label(stage, "A PAST SELF STANDS IN YOUR WAY"), "The reveal overlay should clear before combat.")
					boss.begin_attack_telegraph()
					_expect(boss.is_attack_telegraphed(), "The Floor five boss should visibly telegraph its ranged attack.")
					boss.take_damage(100000)
					await physics_frame
					_expect(room.is_exit_unlocked(), "Defeating the Floor five boss should unlock the exit.")
					_expect(room.get_encounter_state() == DungeonRoom.EncounterState.CLEARED, "A defeated boss encounter should transition to cleared.")
					floor5_boss_verified = true
				elif boss != null and floor_index == 9:
					_expect(boss.boss_id == &"hollow_warden", "Floor ten should spawn the final boss.")
					_expect(boss.max_health == 600, "The final boss should retain the baseline 600-health tuning.")
					_expect(boss.attack_damage == 18, "The final boss volley damage should match the tested baseline.")
					boss.take_damage(100000)
					_expect(room.is_exit_unlocked(), "Defeating the final boss should clear its locked room.")
					_expect(not stage.is_processing(), "Exit monitoring should stop when the run finishes.")
					final_boss_verified = true
					completed_by_final_boss = true
				else:
					_expect(false, "A boss should appear only in the configured Floor five and Floor ten rooms.")
				if completed_by_final_boss:
					await process_frame
					traversed_rooms += 1
					break
				await physics_frame
				_expect(room.is_exit_unlocked(), "Every boss room should unlock only after the boss is defeated.")
				player = stage.get_node("Player") as RunnerController
				player.position = Vector2(270.0, 76.0)
				stage.call("_process", 0.0)
				await physics_frame
				await process_frame
				traversed_rooms += 1
				room_layout_seed += 1
				continue
			var expected_layout_index := room_layout_seed % 4
			_expect(room.get_layout_index() == expected_layout_index, "Room layouts should follow a repeatable four-layout sequence.")
			room_layout_mask = room_layout_mask | (1 << expected_layout_index)
			if floor_index == 1 and room_index == floor_definition.echo_room_index:
				var echoes: Array[FacilityEnemy] = []
				for enemy in room_enemies.get_children():
					var candidate := enemy as FacilityEnemy
					if candidate != null and candidate.is_previous_self:
						echoes.append(candidate)
				_expect(echoes.size() == 1, "A configured later-floor room should spawn the saved previous self.")
				if not echoes.is_empty():
					var echo := echoes[0]
					_expect(echo.max_health < int(saved_snapshot.get("max_health", 100)), "A previous self should be weaker than its source character.")
					_expect(echo.attack_damage < int(saved_snapshot.get("attack_damage", 10)), "A previous self should deal reduced snapshot damage.")
					_expect(echo._has_crossbow, "A previous self should use its saved crossbow archetype.")
					var firing_lane_x := 180.0 if room.get_layout_index() == 3 else 270.0
					echo.target = null
					echo.global_position = Vector2(firing_lane_x, 250.0)
					player = stage.get_node("Player") as RunnerController
					player.global_position = Vector2(firing_lane_x, 450.0)
					var health_before_echo_shot := player.health
					echo._spawn_echo_projectile(Vector2.DOWN)
					for _frame in 30:
						await physics_frame
					_expect(player.health < health_before_echo_shot, "A previous-self projectile should collide with and damage the player.")
					echo_combat_verified = true
			for enemy in room_enemies.get_children():
				var combatant := enemy as FacilityEnemy
				if combatant != null:
					combatant.take_damage(10000)
			await physics_frame
			_expect(room.is_exit_unlocked(), "Every room should unlock its exit when its enemies are defeated.")
			player = stage.get_node("Player") as RunnerController
			player.position = Vector2(270.0, 76.0)
			stage.call("_process", 0.0)
			await physics_frame
			await process_frame
			traversed_rooms += 1
			room_layout_seed += 1
		if completed_by_final_boss:
			break
	_expect(traversed_rooms == 38, "The test run should traverse all 38 rooms.")
	_expect(room_layout_mask == 0b1111, "The complete run should exercise all four deterministic room layouts.")
	_expect(echo_combat_verified, "The full run should verify snapshot echo combat.")
	_expect(floor5_boss_verified, "The Floor five boss, one-time reveal, telegraph, and locked exit should be verified.")
	_expect(final_boss_verified and completed_by_final_boss, "Defeating the Floor ten boss should directly complete the run.")
	await process_frame
	_expect(main.get("_stage") == null, "Clearing floor ten should complete the run.")
	_expect(_contains_label(main, "FACILITY CLEARED"), "The end screen should report a completed run.")
	_expect(manager.points == 40, "A win should award exactly thirty additional scrap.")
	_expect(manager.purchase_upgrade("health"), "The health upgrade should be purchasable.")
	_expect(int(manager.get_player_stats()["max_health"]) == 110, "The health upgrade should add ten maximum HP.")
	_expect(manager.points == 20, "The health upgrade should deduct its configured price.")
	_expect(not manager.purchase_upgrade("warden_crossbow"), "Weapon upgrades should reject purchases without enough currency.")
	manager.points = 30
	_expect(manager.purchase_upgrade("warden_crossbow"), "The crossbow damage upgrade should be purchasable when affordable.")
	_expect(is_equal_approx(float(manager.get_player_stats()["crossbow_damage_multiplier"]), 1.12), "The crossbow upgrade should improve bolt damage.")
	_expect(manager.is_upgrade_maxed("warden_crossbow") == false, "A weapon upgrade should remain below maximum after one purchase.")

	if is_instance_valid(main):
		main.queue_free()
	await process_frame
	if _failed:
		quit(1)
	else:
		print("PASS: Guide UI/mobile and content milestones, all room layouts, and the complete ten-floor run.")
		quit(0)


func _expect(condition: bool, description: String) -> void:
	if condition:
		return
	_failed = true
	push_error("FAIL: %s" % description)


func _contains_label(node: Node, expected: String) -> bool:
	if node is Label and (node as Label).text.contains(expected):
		return true
	for child in node.get_children():
		if _contains_label(child, expected):
			return true
	return false


func _find_button(node: Node, expected_text: String) -> Button:
	if node is Button and (node as Button).text == expected_text:
		return node as Button
	for child in node.get_children():
		var found := _find_button(child, expected_text)
		if found != null:
			return found
	return null
