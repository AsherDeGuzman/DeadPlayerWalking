extends Control
class_name TouchControls

signal attack_pressed
signal weapon_switch_pressed
signal dodge_pressed
signal interact_pressed

const JOYSTICK_RADIUS := 66.0
const JOYSTICK_HIT_RADIUS := 102.0

var _movement_finger := -1
var _movement_position := Vector2.ZERO
var _mouse_movement_held := false
var _pressed_action := ""
var _action_finger := -1
var _weapon_icons: Texture2D
var _attack_label := "STRIKE"


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_weapon_icons = load("res://assets/weapons/weapon_icons.png") as Texture2D
	get_viewport().size_changed.connect(queue_redraw)
	if _weapon_icons == null:
		push_error("Could not load weapon icons for the touch controls.")


func get_movement_vector() -> Vector2:
	if _movement_finger == -1 and not _mouse_movement_held:
		return Vector2.ZERO
	var center := _joystick_center()
	return ((_movement_position - center) / (JOYSTICK_RADIUS * _layout_scale())).limit_length(1.0)


func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		var touch := event as InputEventScreenTouch
		if touch.pressed:
			_handle_press(touch.position, touch.index)
		else:
			_handle_release(touch.index)
	elif event is InputEventScreenDrag:
		var drag := event as InputEventScreenDrag
		if drag.index == _movement_finger:
			_movement_position = drag.position
			queue_redraw()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		var mouse_button := event as InputEventMouseButton
		if mouse_button.pressed:
			_handle_press(mouse_button.position, -2)
		else:
			_handle_release(-2)
	elif event is InputEventMouseMotion and _mouse_movement_held:
		_movement_position = (event as InputEventMouseMotion).position
		queue_redraw()


func _handle_press(position: Vector2, finger: int) -> void:
	var scale_factor := _layout_scale()
	if position.distance_to(_joystick_center()) <= JOYSTICK_HIT_RADIUS * scale_factor and _movement_finger == -1:
		_movement_finger = finger
		_movement_position = position
		_mouse_movement_held = finger == -2
		queue_redraw()
		return

	if position.distance_to(_attack_center()) <= 56.0 * scale_factor:
		_pressed_action = "attack"
		_action_finger = finger
		attack_pressed.emit()
	elif position.distance_to(_weapon_switch_center()) <= 42.0 * scale_factor:
		_pressed_action = "weapon_switch"
		_action_finger = finger
		weapon_switch_pressed.emit()
	elif position.distance_to(_dodge_center()) <= 53.0 * scale_factor:
		_pressed_action = "dodge"
		_action_finger = finger
		dodge_pressed.emit()
	elif position.distance_to(_interact_center()) <= 38.0 * scale_factor:
		_pressed_action = "interact"
		_action_finger = finger
		interact_pressed.emit()
	queue_redraw()


func _handle_release(finger: int) -> void:
	if finger == _movement_finger:
		_movement_finger = -1
		_mouse_movement_held = false
		_movement_position = Vector2.ZERO
	if finger == _action_finger:
		_pressed_action = ""
		_action_finger = -1
	queue_redraw()


func _joystick_center() -> Vector2:
	return _joystick_center_for_size(get_viewport_rect().size)


func _joystick_center_for_size(viewport_size: Vector2) -> Vector2:
	var scale_factor := _layout_scale_for_size(viewport_size)
	return Vector2(maxf(102.0 * scale_factor, viewport_size.x * 0.2), viewport_size.y - 143.0 * scale_factor)


func _attack_center() -> Vector2:
	var viewport_size := get_viewport_rect().size
	var scale_factor := _layout_scale_for_size(viewport_size)
	return Vector2(viewport_size.x - 173.0 * scale_factor, viewport_size.y - 137.0 * scale_factor)


func _dodge_center() -> Vector2:
	var viewport_size := get_viewport_rect().size
	var scale_factor := _layout_scale_for_size(viewport_size)
	return Vector2(viewport_size.x - 76.0 * scale_factor, viewport_size.y - 240.0 * scale_factor)


func _weapon_switch_center() -> Vector2:
	var viewport_size := get_viewport_rect().size
	var scale_factor := _layout_scale_for_size(viewport_size)
	return Vector2(viewport_size.x - 76.0 * scale_factor, viewport_size.y - 350.0 * scale_factor)


func _interact_center() -> Vector2:
	var viewport_size := get_viewport_rect().size
	var scale_factor := _layout_scale_for_size(viewport_size)
	return Vector2(viewport_size.x - 76.0 * scale_factor, viewport_size.y - 105.0 * scale_factor)


func _layout_scale() -> float:
	return _layout_scale_for_size(get_viewport_rect().size)


func _layout_scale_for_size(viewport_size: Vector2) -> float:
	return clampf(minf(viewport_size.x / 540.0, viewport_size.y / 960.0), 0.72, 1.35)


func get_action_centers() -> Dictionary:
	return get_action_centers_for_size(get_viewport_rect().size)


func get_action_centers_for_size(viewport_size: Vector2) -> Dictionary:
	var scale_factor := _layout_scale_for_size(viewport_size)
	return {
		"joystick": _joystick_center_for_size(viewport_size),
		"attack": Vector2(viewport_size.x - 173.0 * scale_factor, viewport_size.y - 137.0 * scale_factor),
		"switch": Vector2(viewport_size.x - 76.0 * scale_factor, viewport_size.y - 350.0 * scale_factor),
		"dodge": Vector2(viewport_size.x - 76.0 * scale_factor, viewport_size.y - 240.0 * scale_factor),
		"interact": Vector2(viewport_size.x - 76.0 * scale_factor, viewport_size.y - 105.0 * scale_factor),
	}


func set_weapon(weapon_id: StringName) -> void:
	_attack_label = "BOLT" if weapon_id == &"warden_crossbow" else "STRIKE"
	queue_redraw()


func _draw() -> void:
	var scale_factor := _layout_scale()
	var joystick_radius := JOYSTICK_RADIUS * scale_factor
	var center := _joystick_center()
	var knob_position := center
	if _movement_finger != -1 or _mouse_movement_held:
		knob_position = center + (_movement_position - center).limit_length(joystick_radius)

	draw_circle(center, 57.0 * scale_factor, Color(0.06, 0.12, 0.15, 0.52))
	draw_arc(center, 58.0 * scale_factor, 0.0, TAU, 44, Color(0.55, 0.82, 0.75, 0.28), 2.0 * scale_factor, true)
	draw_circle(knob_position, 27.0 * scale_factor, Color(0.42, 0.76, 0.67, 0.50))
	draw_arc(knob_position, 27.0 * scale_factor, 0.0, TAU, 36, Color(0.82, 0.98, 0.88, 0.55), 2.0 * scale_factor, true)

	_draw_action(_attack_center(), 42.0 * scale_factor, _attack_label, Color("e6ad76"), _pressed_action == "attack")
	_draw_action(_weapon_switch_center(), 34.0 * scale_factor, "SWAP", Color("b18c9a"), _pressed_action == "weapon_switch")
	_draw_action(_dodge_center(), 36.0 * scale_factor, "DASH", Color("76ceb8"), _pressed_action == "dodge")
	_draw_action(_interact_center(), 29.0 * scale_factor, "USE", Color("b0c5d0"), _pressed_action == "interact")


func _draw_action(center: Vector2, radius: float, title: String, tint: Color, pressed: bool) -> void:
	var fill := tint
	fill.a = 0.47 if pressed else 0.25
	draw_circle(center, radius, fill)
	draw_arc(center, radius, 0.0, TAU, 40, Color(tint.r, tint.g, tint.b, 0.69), 2.0, true)
	var font := ThemeDB.fallback_font
	if _weapon_icons != null and title in ["STRIKE", "BOLT"]:
		var source := Rect2(338, 64, 207, 760) if title == "STRIKE" else Rect2(944, 64, 590, 760)
		var icon_size := Vector2(12, 24) if title == "STRIKE" else Vector2(26, 22)
		draw_texture_rect_region(
			_weapon_icons,
			Rect2(center - Vector2(icon_size.x * 0.5, 21), icon_size),
			source
		)
		draw_string(font, center + Vector2(0, 28), title, HORIZONTAL_ALIGNMENT_CENTER, radius * 2.2, 9, Color("f5f5e9"))
	else:
		draw_string(font, center + Vector2(0, 5), title, HORIZONTAL_ALIGNMENT_CENTER, radius * 2.2, 10, Color("f5f5e9"))
