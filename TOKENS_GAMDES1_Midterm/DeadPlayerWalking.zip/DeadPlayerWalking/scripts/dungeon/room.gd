extends Node2D
class_name DungeonRoom

enum EncounterState { COMBAT, BOSS, CLEARED }

signal room_cleared(floor_number: int, room_number: int)
signal exit_entered
signal boss_encounter_started(boss: DungeonBoss)
signal boss_health_changed(boss_name: String, current: int, maximum: int)
signal boss_defeated(boss_id: StringName)

const ROOM_SIZE := Vector2(540.0, 1000.0)
const EXIT_GATE_SIZE := Vector2(148.0, 24.0)
const ROOM_OBSTACLE_LAYOUTS := [
	[],
	[Rect2(72.0, 402.0, 112.0, 22.0), Rect2(356.0, 532.0, 112.0, 22.0)],
	[Rect2(52.0, 430.0, 92.0, 24.0), Rect2(396.0, 532.0, 92.0, 24.0)],
	[Rect2(208.0, 402.0, 124.0, 22.0), Rect2(208.0, 532.0, 124.0, 22.0)],
]

var floor_definition: FloorDefinition
var room_index := 0
var layout_seed := 0
var player: RunnerController
var enemy_scene: PackedScene
var previous_self_scene: PackedScene
var boss_scene: PackedScene
var echo_snapshot: Dictionary = {}
var _remaining_enemies := 0
var _is_cleared := false
var _encounter_state := EncounterState.COMBAT
var _exit_gate: StaticBody2D
var _enemy_container: Node2D
var _world_geometry: Node2D
var _layout_index := -1
var _obstacle_rects: Array[Rect2] = []


func configure(
	definition: FloorDefinition,
	index: int,
	player_node: RunnerController,
	enemy_packed_scene: PackedScene,
	echo_packed_scene: PackedScene,
	boss_packed_scene: PackedScene,
	snapshot: Dictionary,
	room_layout_seed: int = 0
) -> void:
	floor_definition = definition
	room_index = index
	player = player_node
	enemy_scene = enemy_packed_scene
	previous_self_scene = echo_packed_scene
	boss_scene = boss_packed_scene
	echo_snapshot = snapshot.duplicate(true)
	layout_seed = room_layout_seed


func _ready() -> void:
	if floor_definition == null or player == null or enemy_scene == null:
		push_error("A dungeon room was added without its floor, player, or enemy configuration.")
		return
	_world_geometry = Node2D.new()
	_world_geometry.name = "WorldGeometry"
	add_child(_world_geometry)
	_enemy_container = Node2D.new()
	_enemy_container.name = "Enemies"
	add_child(_enemy_container)
	_build_room_geometry()
	_spawn_enemies()
	_create_exit_trigger()
	queue_redraw()


func get_remaining_enemy_count() -> int:
	return _remaining_enemies


func is_exit_unlocked() -> bool:
	return _is_cleared


func is_boss_encounter() -> bool:
	return _encounter_state == EncounterState.BOSS


func get_encounter_state() -> EncounterState:
	return _encounter_state


func get_layout_index() -> int:
	return _layout_index


func get_obstacle_count() -> int:
	return _obstacle_rects.size()


func is_player_at_exit(player_node: Node2D) -> bool:
	if player_node == null:
		return false
	var offset := player_node.global_position - global_position - Vector2(ROOM_SIZE.x * 0.5, 76.0)
	return absf(offset.x) <= 100.0 and absf(offset.y) <= 62.0


func _spawn_enemies() -> void:
	if floor_definition.boss_id != &"" and room_index == floor_definition.room_count - 1:
		_spawn_boss()
		return

	var enemy_count := floor_definition.base_enemy_count + mini(floori(float(room_index) / 2.0), 2)
	_remaining_enemies = 0
	var spawn_columns := [132.0, 270.0, 408.0]
	for enemy_index in enemy_count:
		var enemy := enemy_scene.instantiate() as FacilityEnemy
		if enemy == null:
			push_error("The configured dungeon enemy scene is not a FacilityEnemy.")
			continue
		enemy.position = Vector2(
			spawn_columns[enemy_index % spawn_columns.size()],
			350.0 + float(enemy_index / spawn_columns.size()) * 130.0
		)
		_enemy_container.add_child(enemy)
		enemy.configure_player(player)
		enemy.configure_for_floor(floor_definition.floor_number)
		enemy.defeated.connect(_on_enemy_defeated)
		_remaining_enemies += 1
	if (
		previous_self_scene != null
		and not echo_snapshot.is_empty()
		and floor_definition.echo_room_index == room_index
	):
		var echo := previous_self_scene.instantiate() as FacilityEnemy
		if echo == null:
			push_error("The configured previous-self scene is not a FacilityEnemy.")
		else:
			echo.position = Vector2(270.0, 250.0)
			_enemy_container.add_child(echo)
			echo.configure_player(player, echo_snapshot)
			echo.defeated.connect(_on_enemy_defeated)
			_remaining_enemies += 1
	if _remaining_enemies == 0:
		_unlock_exit()


func _spawn_boss() -> void:
	_encounter_state = EncounterState.BOSS
	_remaining_enemies = 1
	if boss_scene == null:
		push_error("A boss floor reached its encounter room without a boss scene.")
		return
	var boss := boss_scene.instantiate() as DungeonBoss
	if boss == null:
		push_error("The configured dungeon boss scene is not a DungeonBoss.")
		return
	boss.position = Vector2(270.0, 320.0)
	_enemy_container.add_child(boss)
	var source_snapshot := echo_snapshot if not echo_snapshot.is_empty() else player.build_run_record()
	boss.configure(player, source_snapshot, floor_definition.boss_id == &"hollow_warden")
	boss.health_changed.connect(_on_boss_health_changed)
	boss.defeated.connect(_on_boss_defeated)
	_on_boss_health_changed(boss.boss_name, boss.health, boss.max_health)
	boss_encounter_started.emit(boss)


func _on_boss_health_changed(boss_name: String, current: int, maximum: int) -> void:
	boss_health_changed.emit(boss_name, current, maximum)


func _on_boss_defeated(boss_id: StringName) -> void:
	boss_defeated.emit(boss_id)
	_on_enemy_defeated(String(boss_id))


func _on_enemy_defeated(_enemy_type: String) -> void:
	_remaining_enemies = maxi(0, _remaining_enemies - 1)
	if _remaining_enemies == 0:
		_unlock_exit()


func _unlock_exit() -> void:
	if _is_cleared:
		return
	_is_cleared = true
	_encounter_state = EncounterState.CLEARED
	if is_instance_valid(_exit_gate):
		_exit_gate.queue_free()
	room_cleared.emit(floor_definition.floor_number, room_index + 1)
	var audio_manager := get_node_or_null("/root/AudioManager") as GameAudioManager
	if audio_manager != null:
		audio_manager.play_sfx("ui")
	queue_redraw()
	if is_player_at_exit(player):
		call_deferred("_emit_exit_for_waiting_player")


func _emit_exit_for_waiting_player() -> void:
	if _is_cleared and is_instance_valid(player) and is_player_at_exit(player):
		exit_entered.emit()


func _create_exit_trigger() -> void:
	var exit_trigger := Area2D.new()
	exit_trigger.name = "ExitTrigger"
	exit_trigger.collision_layer = 0
	exit_trigger.collision_mask = 1
	var trigger_shape := CollisionShape2D.new()
	var rectangle := RectangleShape2D.new()
	rectangle.size = Vector2(176.0, 58.0)
	trigger_shape.shape = rectangle
	exit_trigger.add_child(trigger_shape)
	exit_trigger.position = Vector2(ROOM_SIZE.x * 0.5, 76.0)
	exit_trigger.body_entered.connect(_on_exit_body_entered)
	add_child(exit_trigger)


func _on_exit_body_entered(body: Node2D) -> void:
	if _is_cleared and body == player:
		exit_entered.emit()


func _build_room_geometry() -> void:
	_add_wall(Rect2(-18.0, 0.0, 36.0, ROOM_SIZE.y))
	_add_wall(Rect2(ROOM_SIZE.x - 18.0, 0.0, 36.0, ROOM_SIZE.y))
	_add_wall(Rect2(0.0, ROOM_SIZE.y - 6.0, ROOM_SIZE.x, 36.0))
	_add_wall(Rect2(0.0, -6.0, 196.0, 36.0))
	_add_wall(Rect2(ROOM_SIZE.x - 196.0, -6.0, 196.0, 36.0))
	_exit_gate = _add_wall(Rect2(
		(ROOM_SIZE.x - EXIT_GATE_SIZE.x) * 0.5,
		22.0,
		EXIT_GATE_SIZE.x,
		EXIT_GATE_SIZE.y
	))
	_exit_gate.name = "LockedExit"

	if floor_definition.boss_id != &"" and room_index == floor_definition.room_count - 1:
		return
	_layout_index = posmod(layout_seed, ROOM_OBSTACLE_LAYOUTS.size())
	var layout: Array = ROOM_OBSTACLE_LAYOUTS[_layout_index]
	for obstacle_index in layout.size():
		var bounds: Rect2 = layout[obstacle_index]
		_obstacle_rects.append(bounds)
		_add_wall(bounds)


func _add_wall(bounds: Rect2) -> StaticBody2D:
	var wall := StaticBody2D.new()
	wall.collision_layer = 4
	wall.collision_mask = 0
	wall.position = bounds.position + bounds.size * 0.5
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = bounds.size
	collision.shape = shape
	wall.add_child(collision)
	_world_geometry.add_child(wall)
	return wall


func _draw() -> void:
	if floor_definition == null:
		return
	draw_rect(Rect2(Vector2.ZERO, ROOM_SIZE), Color("10181c"))
	draw_rect(Rect2(18.0, 18.0, ROOM_SIZE.x - 36.0, ROOM_SIZE.y - 36.0), floor_definition.theme_color)
	draw_rect(Rect2(18.0, 18.0, ROOM_SIZE.x - 36.0, ROOM_SIZE.y - 36.0), Color(0.65, 0.78, 0.72, 0.35), false, 3.0)
	for y in range(42, int(ROOM_SIZE.y) - 30, 48):
		draw_line(Vector2(28.0, y), Vector2(ROOM_SIZE.x - 28.0, y), Color(0.72, 0.84, 0.78, 0.045), 1.0, true)
	for x in range(42, int(ROOM_SIZE.x) - 30, 48):
		draw_line(Vector2(x, 38.0), Vector2(x, ROOM_SIZE.y - 28.0), Color(0.72, 0.84, 0.78, 0.035), 1.0, true)
	for bounds in _obstacle_rects:
		_draw_obstacle(bounds)
	var font := ThemeDB.fallback_font
	draw_string(
		font,
		Vector2(30.0, 82.0),
		"ROOM %02d  /  %02d" % [room_index + 1, floor_definition.room_count],
		HORIZONTAL_ALIGNMENT_LEFT,
		-1.0,
		11,
		Color("c4d5c9")
	)
	if _is_cleared:
		draw_arc(Vector2(ROOM_SIZE.x * 0.5, 48.0), 30.0, 0.0, TAU, 32, Color("8fd5ac"), 3.0, true)
	else:
		draw_rect(Rect2((ROOM_SIZE.x - EXIT_GATE_SIZE.x) * 0.5, 11.0, EXIT_GATE_SIZE.x, 22.0), Color("a36158"))


func _draw_obstacle(bounds: Rect2) -> void:
	var stone_color := floor_definition.theme_color.lightened(0.3)
	var outline_color := floor_definition.theme_color.lightened(0.58)
	draw_rect(Rect2(bounds.position + Vector2(4.0, 6.0), bounds.size), Color(0.02, 0.025, 0.03, 0.55))
	draw_rect(bounds, stone_color)
	draw_rect(bounds, outline_color, false, 2.0)
	var inset := bounds.grow(-5.0)
	if inset.size.x > 0.0 and inset.size.y > 0.0:
		draw_line(inset.position, Vector2(inset.end.x, inset.position.y), outline_color.darkened(0.2), 1.0, true)
