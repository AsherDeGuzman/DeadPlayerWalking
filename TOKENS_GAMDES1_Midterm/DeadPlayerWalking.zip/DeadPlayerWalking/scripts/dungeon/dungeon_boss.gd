extends CharacterBody2D
class_name DungeonBoss

signal health_changed(boss_name: String, current: int, maximum: int)
signal defeated(boss_id: StringName)

const PROJECTILE_SCENE := preload("res://scenes/projectiles/crossbow_projectile.tscn")

var target: RunnerController
var boss_id: StringName = &"previous_self"
var boss_name := "THE PREVIOUS SELF"
var is_final_boss := false
var max_health := 220
var health := 220
var attack_damage := 12
var movement_speed := 92.0
var _audio_manager: GameAudioManager
var _is_active := false
var _windup_time := 0.0
var _attack_cooldown := 1.0
var _facing := Vector2.DOWN
var _hit_flash := 0.0


func _ready() -> void:
	_audio_manager = get_node("/root/AudioManager") as GameAudioManager
	add_to_group("enemies")
	set_physics_process(false)


func configure(player: RunnerController, source_snapshot: Dictionary, final_boss: bool) -> void:
	target = player
	is_final_boss = final_boss
	boss_id = &"hollow_warden" if is_final_boss else &"previous_self"
	boss_name = "THE HOLLOW WARDEN" if is_final_boss else "THE PREVIOUS SELF"
	var source_health := clampi(int(source_snapshot.get("max_health", 100)), 1, 2000)
	var source_damage := clampi(int(source_snapshot.get("attack_damage", 10)), 1, 100)
	var source_speed := clampf(float(source_snapshot.get("move_speed", 200.0)), 80.0, 400.0)
	if is_final_boss:
		max_health = maxi(600, roundi(float(source_health) * 4.0))
		attack_damage = maxi(18, roundi(float(source_damage) * 1.8))
		movement_speed = minf(source_speed * 0.55, 150.0)
	else:
		max_health = maxi(220, roundi(float(source_health) * 2.0))
		attack_damage = maxi(12, roundi(float(source_damage) * 1.2))
		movement_speed = minf(source_speed * 0.5, 120.0)
	health = max_health
	health_changed.emit(boss_name, health, max_health)
	queue_redraw()


func start_encounter() -> void:
	_is_active = true
	set_physics_process(true)


func is_attack_telegraphed() -> bool:
	return _windup_time > 0.0


func begin_attack_telegraph() -> void:
	_windup_time = 0.82 if is_final_boss else 1.0
	_audio_manager.play_sfx("enemy_windup")
	queue_redraw()


func take_damage(amount: int) -> void:
	if not _is_active or health <= 0 or amount <= 0:
		return
	health = maxi(0, health - amount)
	_hit_flash = 0.16
	health_changed.emit(boss_name, health, max_health)
	queue_redraw()
	if health == 0:
		_is_active = false
		set_physics_process(false)
		defeated.emit(boss_id)
		queue_free()


func _physics_process(delta: float) -> void:
	if target == null or not is_instance_valid(target) or not target.is_alive:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	_attack_cooldown = maxf(0.0, _attack_cooldown - delta)
	_hit_flash = maxf(0.0, _hit_flash - delta)
	var offset := target.global_position - global_position
	var distance := offset.length()
	if distance > 0.01:
		_facing = offset.normalized()
	velocity = offset.normalized() * movement_speed if distance > 210.0 else Vector2.ZERO
	move_and_slide()

	if _attack_cooldown <= 0.0 and _windup_time <= 0.0 and distance <= 640.0:
		begin_attack_telegraph()
	if _windup_time > 0.0:
		_windup_time = maxf(0.0, _windup_time - delta)
		if _windup_time <= 0.0:
			_fire_attack()
			_attack_cooldown = 1.65 if is_final_boss else 2.0
	queue_redraw()


func _fire_attack() -> void:
	if target == null or not is_instance_valid(target):
		return
	var direction := (target.global_position - global_position).normalized()
	if direction.length_squared() < 0.01:
		direction = _facing
	var spread := [-0.2, 0.0, 0.2] if is_final_boss else [0.0]
	for angle in spread:
		var projectile := PROJECTILE_SCENE.instantiate() as CrossbowProjectile
		if projectile == null:
			push_error("The boss projectile scene could not be instantiated.")
			continue
		projectile.name = "BossProjectile"
		projectile.configure(direction.rotated(angle), attack_damage, 470.0, 640.0, &"player")
		get_parent().add_child(projectile)
		projectile.global_position = global_position + direction * 34.0


func _draw() -> void:
	var outer_color := Color("a66a9a") if not is_final_boss else Color("8956b2")
	var core_color := Color("3c263f") if not is_final_boss else Color("281d43")
	if _hit_flash > 0.0:
		outer_color = Color("fff0d4")
	draw_circle(Vector2(0, 12), 37, Color(0.008, 0.012, 0.018, 0.58))
	draw_circle(Vector2.ZERO, 32, core_color)
	draw_circle(Vector2.ZERO, 27, outer_color)
	draw_circle(Vector2.ZERO, 19, Color("39273b"))
	draw_circle(Vector2(-8, -5), 4, Color("ffe6be"))
	draw_circle(Vector2(8, -5), 4, Color("ffe6be"))
	draw_line(Vector2.ZERO, _facing * 43.0, Color("ffd2a1"), 5.0, true)
	draw_line(Vector2(-18, -23), Vector2(-30, -42), outer_color, 7.0, true)
	draw_line(Vector2(18, -23), Vector2(30, -42), outer_color, 7.0, true)
	draw_arc(Vector2.ZERO, 43.0, 0.0, TAU, 40, Color(0.94, 0.57, 0.78, 0.65), 2.0, true)
	if is_attack_telegraphed():
		var progress := 1.0 - _windup_time / (0.82 if is_final_boss else 1.0)
		var telegraph_color := Color(1.0, 0.75, 0.38, 0.45 + progress * 0.5)
		draw_arc(Vector2.ZERO, 54.0 + progress * 12.0, 0.0, TAU, 40, telegraph_color, 4.0, true)
	var font := ThemeDB.fallback_font
	draw_string(font, Vector2(-72.0, -53.0), boss_name, HORIZONTAL_ALIGNMENT_CENTER, 144.0, 10, Color("f5d9e8"))
