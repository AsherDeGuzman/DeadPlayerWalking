extends Node
class_name GameAudioManager

const FACILITY_AMBIENCE_PATH := "res://assets/audio/facility_ambience.wav"
const EFFECT_PATHS: Dictionary = {
	"attack": "res://assets/audio/strike.wav",
	"dash": "res://assets/audio/dash.wav",
	"damage": "res://assets/audio/damage.wav",
	"footstep": "res://assets/audio/footstep.wav",
	"enemy_windup": "res://assets/audio/enemy_windup.wav",
	"enemy_down": "res://assets/audio/enemy_down.wav",
	"hazard": "res://assets/audio/hazard_warning.wav",
	"victory": "res://assets/audio/victory.wav",
	"defeat": "res://assets/audio/defeat.wav",
	"ui": "res://assets/audio/ui_confirm.wav",
	"echo": "res://assets/audio/echo.wav",
}
const SFX_CHANNEL_COUNT := 8

var _music_player: AudioStreamPlayer
var _music_stream: AudioStreamWAV
var _sfx_players: Array[AudioStreamPlayer] = []
var _effects: Dictionary = {}
var _next_sfx_channel := 0
var gameplay_paused := false
var music_volume := 1.0
var sfx_volume := 1.0


func _ready() -> void:
	_music_player = AudioStreamPlayer.new()
	_music_player.name = "FacilityAmbience"
	_music_player.process_mode = Node.PROCESS_MODE_ALWAYS
	_music_stream = _load_wave(FACILITY_AMBIENCE_PATH)
	if _music_stream == null:
		return
	_music_stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	_music_player.stream = _music_stream
	_music_player.volume_db = _volume_db(music_volume, -13.0)
	_music_player.bus = "Master"
	add_child(_music_player)
	_music_player.play()

	for effect_name in EFFECT_PATHS:
		var effect_stream := _load_wave(str(EFFECT_PATHS[effect_name]))
		if effect_stream != null:
			_effects[effect_name] = effect_stream

	for channel_index in range(SFX_CHANNEL_COUNT):
		var player := AudioStreamPlayer.new()
		player.name = "SfxChannel%02d" % channel_index
		player.process_mode = Node.PROCESS_MODE_ALWAYS
		player.bus = "Master"
		add_child(player)
		_sfx_players.append(player)


func play_sfx(effect_name: String) -> void:
	if not _effects.has(effect_name):
		push_error("Sound effect is missing or could not be loaded: %s" % effect_name)
		return

	var player := _sfx_players[_next_sfx_channel]
	_next_sfx_channel = (_next_sfx_channel + 1) % SFX_CHANNEL_COUNT
	player.stream = _effects[effect_name]
	player.volume_db = _volume_db(sfx_volume, -8.0)
	player.play()


func set_music_volume(value: float) -> void:
	music_volume = clampf(value, 0.0, 1.0)
	if _music_player != null:
		_music_player.volume_db = _volume_db(music_volume, -13.0)


func set_sfx_volume(value: float) -> void:
	sfx_volume = clampf(value, 0.0, 1.0)


func set_gameplay_paused(paused: bool) -> void:
	gameplay_paused = paused
	if _music_player != null:
		_music_player.stream_paused = paused
	for player in _sfx_players:
		player.stream_paused = paused


func _volume_db(value: float, base_db: float) -> float:
	return -80.0 if value <= 0.001 else base_db + linear_to_db(value)


func _load_wave(path: String) -> AudioStreamWAV:
	var stream := AudioStreamWAV.load_from_file(path)
	if stream == null:
		push_error("Could not load generated WAV audio: %s" % path)
	return stream
