extends CharacterBody2D
class_name FacilityEnemy

signal defeated(enemy_type: String)

@export var is_previous_self: bool = false

const FALLBACK_HP := 100
const FALLBACK_DAMAGE := 10
const FALLBACK_SPEED := 155.0
const BASIC_HP := 42
const BASIC_DAMAGE := 8
const BASIC_SPEED := 92.0
const CROSSBOW_PROJECTILE_SCENE := preload("res://scenes/projectiles/crossbow_projectile.tscn")
const ECHO_RANGED_RANGE := 420.0
const ECHO_RANGED_PREFERRED_DISTANCE := 190.0

var target: RunnerController
var _audio_manager: GameAudioManager
var max_health: int = BASIC_HP
var health: int = BASIC_HP
var attack_damage: int = BASIC_DAMAGE
var movement_speed: float = BASIC_SPEED
var echo_label: String = "PREVIOUS SELF"

var _has_crossbow := false
var _windup_time := 0.0
var _windup_is_ranged := false
var _attack_cooldown := 0.7
var _hit_flash := 0.0
var _facing := Vector2.UP


func _ready() -> void:
	_audio_manager = get_node("/root/AudioManager") as GameAudioManager
	add_to_group("enemies")
	if is_previous_self:
		add_to_group("previous_selves")


func configure_player(player: RunnerController, record: Dictionary = {}) -> void:
	target = player
	if not is_previous_self:
		max_health = BASIC_HP
		health = max_health
		attack_damage = BASIC_DAMAGE
		movement_speed = BASIC_SPEED
		_has_crossbow = false
		queue_redraw()
		return

	echo_label = str(record.get("label", "PREVIOUS SELF"))
	var raw_weapons: Variant = record.get("weapon_archetypes", [])
	_has_crossbow = typeof(raw_weapons) == TYPE_ARRAY and "warden_crossbow" in raw_weapons
	if record.is_empty():
		push_warning("Previous-self data was missing; safe default snapshot stats will be used.")
		max_health = roundi(float(FALLBACK_HP) * 0.8)
		health = max_health
		attack_damage = roundi(float(FALLBACK_DAMAGE) * 0.85)
		movement_speed = FALLBACK_SPEED * 0.9
	else:
		max_health = clampi(roundi(float(record.get("max_health", FALLBACK_HP)) * 0.8), 1, 2000)
		health = max_health
		attack_damage = clampi(roundi(float(record.get("attack_damage", FALLBACK_DAMAGE)) * 0.85), 1, 100)
		movement_speed = clampf(float(record.get("move_speed", FALLBACK_SPEED)) * 0.9, 60.0, 400.0)
	queue_redraw()


func configure_for_floor(floor_number: int) -> void:
	if is_previous_self:
		return
	var floor_steps := maxi(0, floor_number - 1)
	max_health = roundi(float(BASIC_HP) * (1.0 + float(floor_steps) * 0.075))
	health = max_health
	attack_damage = roundi(float(BASIC_DAMAGE) * (1.0 + float(floor_steps) * 0.05))
	movement_speed = minf(BASIC_SPEED + float(floor_steps) * 3.0, 155.0)
	queue_redraw()


func weaken_for_opening_strike() -> void:
	var opening_damage := mini(30, maxi(1, max_health / 3))
	health = maxi(1, health - opening_damage)
	queue_redraw()


func take_damage(amount: int) -> void:
	if health <= 0 or amount <= 0:
		return
	health = maxi(0, health - amount)
	_hit_flash = 0.16
	queue_redraw()
	if health == 0:
		defeated.emit("previous_self" if is_previous_self else "ordinary")
		queue_free()


func _physics_process(delta: float) -> void:
	if target == null or not is_instance_valid(target) or not target.is_alive:
		velocity = Vector2.ZERO
		move_and_slide()
		return

	_attack_cooldown = maxf(0.0, _attack_cooldown - delta)
	_hit_flash = maxf(0.0, _hit_flash - delta)
	var offset := target.global_position - global_position
	var distance := offset.length()
	if distance > 0.01:
		_facing = offset.normalized()

	var preferred_distance := ECHO_RANGED_PREFERRED_DISTANCE if is_previous_self and _has_crossbow else 46.0
	velocity = _pursuit_movement(offset, distance, preferred_distance) * movement_speed
	move_and_slide()

	var ranged_attack := is_previous_self and _has_crossbow and distance > 120.0 and distance <= ECHO_RANGED_RANGE
	var attack_range := ECHO_RANGED_RANGE if ranged_attack else 54.0
	if distance <= attack_range and _attack_cooldown <= 0.0 and _windup_time <= 0.0:
		_windup_time = 0.34
		_windup_is_ranged = ranged_attack
		_audio_manager.play_sfx("enemy_windup")
	if _windup_time > 0.0:
		_windup_time = maxf(0.0, _windup_time - delta)
		if _windup_time <= 0.0:
			var target_offset := target.global_position - global_position
			if _windup_is_ranged and target_offset.length() <= ECHO_RANGED_RANGE:
				_spawn_echo_projectile(target_offset.normalized())
			elif target_offset.length() <= 68.0:
				target.take_damage(attack_damage)
			_attack_cooldown = 1.15
			_windup_is_ranged = false
	queue_redraw()


func _pursuit_movement(offset: Vector2, distance: float, preferred_distance: float) -> Vector2:
	if distance > preferred_distance:
		return offset.normalized()
	return Vector2.ZERO


func _spawn_echo_projectile(direction: Vector2) -> void:
	var projectile := CROSSBOW_PROJECTILE_SCENE.instantiate() as CrossbowProjectile
	if projectile == null:
		push_error("The previous-self projectile scene could not be instantiated.")
		return
	projectile.name = "PreviousSelfProjectile"
	projectile.configure(direction, attack_damage, 560.0, ECHO_RANGED_RANGE, &"player")
	get_parent().add_child(projectile)
	projectile.global_position = global_position + direction * 24.0


func _draw() -> void:
	var body_color := Color("f0a36f")
	var core_color := Color("5b2c2d")
	if is_previous_self:
		body_color = Color("e782a2")
		core_color = Color("462738")
	if _hit_flash > 0.0:
		body_color = Color("fff3dc")

	draw_circle(Vector2(0, 7), 21, Color(0.008, 0.012, 0.018, 0.5))
	draw_circle(Vector2.ZERO, 17, core_color)
	draw_circle(Vector2.ZERO, 13, body_color)
	draw_circle(Vector2(-4, -4), 4, Color("fff1d2"))
	draw_line(Vector2.ZERO, _facing * 26.0, Color("f9d1a2"), 4.0, true)
	draw_arc(Vector2.ZERO, 24.0, 0.0, TAU, 28, Color(0.93, 0.48, 0.47, 0.55), 1.5, true)
	if _windup_time > 0.0:
		draw_arc(Vector2.ZERO, 32.0, 0.0, TAU, 28, Color("ffc06e"), 3.0, true)

	var font := ThemeDB.fallback_font
	var name_text := echo_label if is_previous_self else "WALKER"
	draw_string(font, Vector2(-40, -29), name_text, HORIZONTAL_ALIGNMENT_CENTER, 80, 9, Color("f3d9cd"))
	var bar_width := 42.0
	var health_ratio := clampf(float(health) / float(maxi(1, max_health)), 0.0, 1.0)
	draw_rect(Rect2(-bar_width * 0.5, 23.0, bar_width, 4.0), Color("45242c"))
	draw_rect(Rect2(-bar_width * 0.5, 23.0, bar_width * health_ratio, 4.0), Color("ed7182"))
