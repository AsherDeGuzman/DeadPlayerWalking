extends Node
class_name PersistentRunManager

signal run_finished(completed: bool, reward: int, total_points: int, recorded_echo: bool)
signal progression_changed

const SAVE_PATH := "user://dead_player_walking.cfg"
const MAX_ECHO_RECORDS := 3
const UPGRADE_COSTS := {
	"health": 20,
	"damage": 25,
	"speed": 20,
	"dungeon_edge": 30,
	"warden_crossbow": 30,
}
const UPGRADE_MAX_LEVELS := {
	"health": 99,
	"damage": 99,
	"speed": 99,
	"dungeon_edge": 5,
	"warden_crossbow": 5,
}
const UPGRADE_DEFINITIONS := {
	"health": {"name": "VITALS", "description": "+10 maximum health", "stat": "max_health"},
	"damage": {"name": "EDGE", "description": "+2 base attack damage", "stat": "attack_damage"},
	"speed": {"name": "MOBILITY", "description": "+10 movement speed", "stat": "move_speed"},
	"dungeon_edge": {"name": "DUNGEON EDGE", "description": "+12% sword damage", "stat": "sword_damage_multiplier"},
	"warden_crossbow": {"name": "WARDEN CROSSBOW", "description": "+12% bolt damage", "stat": "crossbow_damage_multiplier"},
}

var points: int = 0
var attempts: int = 0
var upgrade_levels: Dictionary = {
	"health": 0,
	"damage": 0,
	"speed": 0,
	"dungeon_edge": 0,
	"warden_crossbow": 0,
}
var echo_records: Array[Dictionary] = []
var run_active: bool = false
var floor5_reveal_seen := false
var music_volume := 1.0
var sfx_volume := 1.0


func _ready() -> void:
	_load_progress()


func get_player_stats() -> Dictionary:
	return {
		"max_health": 100 + int(upgrade_levels["health"]) * 10,
		"attack_damage": 10 + int(upgrade_levels["damage"]) * 2,
		"move_speed": 200.0 + int(upgrade_levels["speed"]) * 10.0,
		"sword_damage_multiplier": 1.0 + int(upgrade_levels["dungeon_edge"]) * 0.12,
		"crossbow_damage_multiplier": 1.0 + int(upgrade_levels["warden_crossbow"]) * 0.12,
	}


func get_progress_snapshot() -> Dictionary:
	return {
		"points": points,
		"attempts": attempts,
		"upgrades": upgrade_levels.duplicate(true),
		"echo_count": echo_records.size(),
		"floor5_reveal_seen": floor5_reveal_seen,
	}


func has_seen_floor5_reveal() -> bool:
	return floor5_reveal_seen


func mark_floor5_reveal_seen() -> void:
	if floor5_reveal_seen:
		return
	floor5_reveal_seen = true
	_save_progress()


func set_audio_volumes(music: float, effects: float) -> void:
	music_volume = clampf(music, 0.0, 1.0)
	sfx_volume = clampf(effects, 0.0, 1.0)


func save_settings() -> void:
	_save_progress()


func get_upgrade_level(upgrade: String) -> int:
	if not upgrade_levels.has(upgrade):
		return 0
	return int(upgrade_levels[upgrade])


func is_upgrade_maxed(upgrade: String) -> bool:
	return UPGRADE_MAX_LEVELS.has(upgrade) and get_upgrade_level(upgrade) >= int(UPGRADE_MAX_LEVELS[upgrade])


func get_echo_records() -> Array[Dictionary]:
	return echo_records.duplicate(true)


func begin_run() -> int:
	if run_active:
		push_warning("A run is already active; the duplicate start request was ignored.")
		return attempts
	run_active = true
	attempts += 1
	_save_progress()
	return attempts


func finish_run(completed: bool, run_record: Dictionary) -> void:
	if not run_active:
		push_warning("A run outcome was received while no run was active.")
		return

	run_active = false
	var reward := 30 if completed else 10
	points += reward
	var recorded_echo := false

	if not completed:
		var safe_record := _sanitize_record(run_record)
		if not safe_record.is_empty():
			echo_records.append(safe_record)
			while echo_records.size() > MAX_ECHO_RECORDS:
				echo_records.pop_front()
			recorded_echo = true

	_save_progress()
	run_finished.emit(completed, reward, points, recorded_echo)
	progression_changed.emit()


func purchase_upgrade(upgrade: String) -> bool:
	if not UPGRADE_COSTS.has(upgrade) or not upgrade_levels.has(upgrade):
		push_warning("Unknown permanent upgrade requested: %s" % upgrade)
		return false
	if is_upgrade_maxed(upgrade):
		return false

	var cost: int = UPGRADE_COSTS[upgrade]
	if points < cost:
		return false

	points -= cost
	upgrade_levels[upgrade] = int(upgrade_levels[upgrade]) + 1
	_save_progress()
	progression_changed.emit()
	return true


func get_upgrade_cost(upgrade: String) -> int:
	if not UPGRADE_COSTS.has(upgrade):
		return 0
	return int(UPGRADE_COSTS[upgrade])


func _sanitize_record(source: Dictionary) -> Dictionary:
	var safe_record := _sanitize_snapshot(source)
	if safe_record.is_empty():
		push_warning("A death snapshot had invalid character statistics and was not saved.")
		return {}
	var record_number := maxi(1, attempts)
	safe_record["label"] = "ECHO-%02d" % record_number
	return safe_record


func _load_progress() -> void:
	var config := ConfigFile.new()
	var result := config.load(SAVE_PATH)
	if result == ERR_FILE_NOT_FOUND:
		return
	if result != OK:
		push_warning("Save data could not be loaded (%s); starting with safe defaults." % error_string(result))
		return

	points = maxi(0, int(config.get_value("progress", "points", 0)))
	attempts = maxi(0, int(config.get_value("progress", "attempts", 0)))
	floor5_reveal_seen = bool(config.get_value("progress", "floor5_reveal_seen", false))
	music_volume = clampf(float(config.get_value("settings", "music_volume", 1.0)), 0.0, 1.0)
	sfx_volume = clampf(float(config.get_value("settings", "sfx_volume", 1.0)), 0.0, 1.0)

	var loaded_upgrades: Variant = config.get_value("progress", "upgrades", {})
	if typeof(loaded_upgrades) == TYPE_DICTIONARY:
		for key in upgrade_levels:
			upgrade_levels[key] = clampi(int(loaded_upgrades.get(key, 0)), 0, int(UPGRADE_MAX_LEVELS[key]))

	var loaded_records: Variant = config.get_value("history", "echoes", [])
	if typeof(loaded_records) == TYPE_ARRAY:
		for item in loaded_records:
			if typeof(item) == TYPE_DICTIONARY:
				var record := _sanitize_loaded_record(item)
				if not record.is_empty():
					echo_records.append(record)
				if echo_records.size() >= MAX_ECHO_RECORDS:
					break


func _sanitize_loaded_record(source: Dictionary) -> Dictionary:
	return _sanitize_snapshot(source)


func _sanitize_snapshot(source: Dictionary) -> Dictionary:
	if not source.has("max_health") or not source.has("attack_damage") or not source.has("move_speed"):
		return {}

	var raw_weapons: Variant = source.get("weapon_archetypes", ["dungeon_edge", "warden_crossbow"])
	if typeof(raw_weapons) != TYPE_ARRAY:
		return {}
	var weapon_archetypes: Array[String] = []
	for item in raw_weapons:
		var weapon_id := str(item)
		if weapon_id in ["dungeon_edge", "warden_crossbow"] and weapon_id not in weapon_archetypes:
			weapon_archetypes.append(weapon_id)
	if weapon_archetypes.is_empty():
		return {}

	var equipped_weapon := str(source.get("equipped_weapon", weapon_archetypes[0]))
	if equipped_weapon not in weapon_archetypes:
		equipped_weapon = weapon_archetypes[0]
	return {
		"label": str(source.get("label", "ECHO")),
		"max_health": clampi(int(source["max_health"]), 1, 2000),
		"attack_damage": clampi(int(source["attack_damage"]), 1, 100),
		"move_speed": clampf(float(source["move_speed"]), 80.0, 400.0),
		"weapon_archetypes": weapon_archetypes,
		"equipped_weapon": equipped_weapon,
	}


func _save_progress() -> void:
	var config := ConfigFile.new()
	config.set_value("progress", "points", points)
	config.set_value("progress", "attempts", attempts)
	config.set_value("progress", "floor5_reveal_seen", floor5_reveal_seen)
	config.set_value("progress", "upgrades", upgrade_levels)
	config.set_value("history", "echoes", echo_records)
	config.set_value("settings", "music_volume", music_volume)
	config.set_value("settings", "sfx_volume", sfx_volume)

	var result := config.save(SAVE_PATH)
	if result != OK:
		push_error("Could not save progression to %s (%s)." % [SAVE_PATH, error_string(result)])
