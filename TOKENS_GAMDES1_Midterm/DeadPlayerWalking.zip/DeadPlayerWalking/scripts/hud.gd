extends CanvasLayer

signal attack_pressed
signal weapon_switch_pressed
signal dodge_pressed
signal interact_pressed
signal pause_pressed

var _health_fill: ColorRect
var _health_label: Label
var _points_label: Label
var _zone_label: Label
var _weapon_label: Label
var _touch_controls: TouchControls
var _screen: Control
var _boss_panel: Control
var _boss_fill: ColorRect
var _boss_label: Label
var _reveal_overlay: Control
var _top_bar: ColorRect
var _pause_button: Button
var _health_track: ColorRect
var _controls_hint: Label
var _boss_track: ColorRect
var _health_ratio := 1.0
var _boss_health_ratio := 1.0


func _ready() -> void:
	layer = 2
	_screen = Control.new()
	_screen.name = "Screen"
	_screen.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_screen.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_screen)

	_top_bar = ColorRect.new()
	_top_bar.position = Vector2.ZERO
	_top_bar.size = Vector2(540, 96)
	_top_bar.color = Color(0.025, 0.045, 0.06, 0.94)
	_top_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_screen.add_child(_top_bar)

	_zone_label = _label("SECTOR 01  /  THE FACILITY", Vector2(20, 12), Vector2(355, 22), 12, Color("8fc9b5"))
	_screen.add_child(_zone_label)
	_points_label = _label("0  SCRAP", Vector2(388, 12), Vector2(90, 22), 11, Color("eac38a"))
	_points_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_screen.add_child(_points_label)

	_pause_button = Button.new()
	_pause_button.name = "PauseButton"
	_pause_button.text = "II"
	_pause_button.tooltip_text = "Pause the run"
	_pause_button.position = Vector2(484, 42)
	_pause_button.size = Vector2(38, 33)
	_pause_button.add_theme_font_size_override("font_size", 12)
	_pause_button.add_theme_color_override("font_color", Color("e8eee8"))
	var pause_style := StyleBoxFlat.new()
	pause_style.bg_color = Color("293c3d")
	pause_style.border_color = Color("647f71")
	pause_style.set_border_width_all(1)
	pause_style.corner_radius_top_left = 5
	pause_style.corner_radius_top_right = 5
	pause_style.corner_radius_bottom_left = 5
	pause_style.corner_radius_bottom_right = 5
	_pause_button.add_theme_stylebox_override("normal", pause_style)
	_pause_button.add_theme_stylebox_override("hover", pause_style)
	_pause_button.pressed.connect(func() -> void: pause_pressed.emit())
	_screen.add_child(_pause_button)

	_health_track = ColorRect.new()
	_health_track.position = Vector2(20, 47)
	_health_track.size = Vector2(340, 11)
	_health_track.color = Color("29363a")
	_health_track.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_screen.add_child(_health_track)

	_health_fill = ColorRect.new()
	_health_fill.position = Vector2(20, 47)
	_health_fill.size = Vector2(340, 11)
	_health_fill.color = Color("77d1ad")
	_health_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_screen.add_child(_health_fill)

	_health_label = _label("100 / 100  HP", Vector2(350, 39), Vector2(130, 25), 12, Color("e8eee8"))
	_health_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_screen.add_child(_health_label)

	_weapon_label = _label("WEAPON: DUNGEON EDGE", Vector2(20, 64), Vector2(220, 16), 8, Color("e6ad76"))
	_screen.add_child(_weapon_label)
	_controls_hint = _label("ATTACK  SPACE   SWITCH  Q   DASH  SHIFT   USE  E", Vector2(20, 80), Vector2(500, 12), 8, Color("7c9295"))
	_screen.add_child(_controls_hint)

	_boss_panel = Control.new()
	_boss_panel.name = "BossHealth"
	_boss_panel.position = Vector2(54, 105)
	_boss_panel.size = Vector2(432, 46)
	_boss_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_boss_panel.visible = false
	_screen.add_child(_boss_panel)
	_boss_track = ColorRect.new()
	_boss_track.position = Vector2(0, 25)
	_boss_track.size = Vector2(432, 12)
	_boss_track.color = Color("352633")
	_boss_track.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_boss_panel.add_child(_boss_track)
	_boss_fill = ColorRect.new()
	_boss_fill.position = _boss_track.position
	_boss_fill.size = _boss_track.size
	_boss_fill.color = Color("d36c9a")
	_boss_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_boss_panel.add_child(_boss_fill)
	_boss_label = _label("", Vector2(0, 0), Vector2(432, 22), 11, Color("f3d9e8"))
	_boss_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_boss_panel.add_child(_boss_label)

	_touch_controls = TouchControls.new()
	_touch_controls.name = "TouchControls"
	_screen.add_child(_touch_controls)
	_touch_controls.attack_pressed.connect(func() -> void: attack_pressed.emit())
	_touch_controls.weapon_switch_pressed.connect(func() -> void: weapon_switch_pressed.emit())
	_touch_controls.dodge_pressed.connect(func() -> void: dodge_pressed.emit())
	_touch_controls.interact_pressed.connect(func() -> void: interact_pressed.emit())
	get_viewport().size_changed.connect(_apply_responsive_layout)
	_apply_responsive_layout()


func set_health(current: int, maximum: int) -> void:
	if _health_label == null:
		return
	var safe_maximum := maxi(1, maximum)
	_health_label.text = "%d / %d  HP" % [current, safe_maximum]
	_health_ratio = clampf(float(current) / float(safe_maximum), 0.0, 1.0)
	_health_fill.size.x = _health_track.size.x * _health_ratio
	if float(current) / float(safe_maximum) <= 0.3:
		_health_fill.color = Color("ed7b77")
	else:
		_health_fill.color = Color("77d1ad")


func set_points(value: int) -> void:
	if _points_label != null:
		_points_label.text = "%d  SCRAP" % value


func set_zone(title: String) -> void:
	if _zone_label != null:
		_zone_label.text = title.to_upper()


func set_boss_health(boss_name: String, current: int, maximum: int) -> void:
	if _boss_panel == null:
		return
	var safe_maximum := maxi(1, maximum)
	_boss_panel.visible = true
	_boss_label.text = "%s  /  %d%%" % [boss_name, roundi(float(current) / float(safe_maximum) * 100.0)]
	_boss_health_ratio = clampf(float(current) / float(safe_maximum), 0.0, 1.0)
	_boss_fill.size.x = _boss_track.size.x * _boss_health_ratio


func hide_boss_health() -> void:
	if _boss_panel != null:
		_boss_panel.visible = false


func is_boss_health_visible() -> bool:
	return _boss_panel != null and _boss_panel.visible


func show_floor5_reveal() -> void:
	hide_floor5_reveal()
	_reveal_overlay = Control.new()
	_reveal_overlay.name = "Floor5Reveal"
	_reveal_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_reveal_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_reveal_overlay.z_index = 20
	_screen.add_child(_reveal_overlay)
	var shade := ColorRect.new()
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0.02, 0.015, 0.04, 0.78)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_reveal_overlay.add_child(shade)
	var title := _label("FLOOR 05  /  THE DEEP REMEMBERS", Vector2(28, 352), Vector2(484, 30), 14, Color("d794b3"))
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_reveal_overlay.add_child(title)
	var subtitle := _label("A PAST SELF STANDS IN YOUR WAY", Vector2(28, 392), Vector2(484, 30), 12, Color("f2e4d7"))
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_reveal_overlay.add_child(subtitle)


func hide_floor5_reveal() -> void:
	if is_instance_valid(_reveal_overlay):
		_reveal_overlay.queue_free()
	_reveal_overlay = null


func set_weapon(display_name: String, weapon_id: StringName) -> void:
	if _weapon_label != null:
		_weapon_label.text = "WEAPON: %s" % display_name
		_weapon_label.add_theme_color_override(
			"font_color",
			Color("b18c9a") if weapon_id == &"warden_crossbow" else Color("e6ad76")
		)
	if _touch_controls != null:
		_touch_controls.set_weapon(weapon_id)


func get_touch_controls() -> TouchControls:
	return _touch_controls


func _apply_responsive_layout() -> void:
	if _screen == null:
		return
	var viewport_size := get_viewport().get_visible_rect().size
	if viewport_size.x <= 0.0 or viewport_size.y <= 0.0:
		return
	var scale_factor := clampf(minf(viewport_size.x / 540.0, viewport_size.y / 960.0), 0.72, 1.35)
	var margin := 20.0 * scale_factor
	_top_bar.size = Vector2(viewport_size.x, 96.0 * scale_factor)
	_zone_label.position = Vector2(margin, 12.0 * scale_factor)
	_zone_label.size = Vector2(maxf(180.0 * scale_factor, viewport_size.x - 205.0 * scale_factor), 22.0 * scale_factor)
	_zone_label.add_theme_font_size_override("font_size", roundi(12.0 * scale_factor))
	_points_label.position = Vector2(viewport_size.x - 152.0 * scale_factor, 12.0 * scale_factor)
	_points_label.size = Vector2(90.0 * scale_factor, 22.0 * scale_factor)
	_points_label.add_theme_font_size_override("font_size", roundi(11.0 * scale_factor))
	_pause_button.position = Vector2(viewport_size.x - 56.0 * scale_factor, 42.0 * scale_factor)
	_pause_button.size = Vector2(38.0 * scale_factor, 33.0 * scale_factor)
	_pause_button.add_theme_font_size_override("font_size", roundi(12.0 * scale_factor))
	_health_track.position = Vector2(margin, 47.0 * scale_factor)
	_health_track.size = Vector2(minf(340.0 * scale_factor, viewport_size.x * 0.64), 11.0 * scale_factor)
	_health_fill.position = _health_track.position
	_health_fill.size = Vector2(_health_track.size.x * _health_ratio, _health_track.size.y)
	_health_label.position = Vector2(_health_track.position.x + _health_track.size.x + 8.0 * scale_factor, 39.0 * scale_factor)
	_health_label.size = Vector2(maxf(70.0 * scale_factor, viewport_size.x - _health_label.position.x - 58.0 * scale_factor), 25.0 * scale_factor)
	_health_label.add_theme_font_size_override("font_size", roundi(12.0 * scale_factor))
	_weapon_label.position = Vector2(margin, 64.0 * scale_factor)
	_weapon_label.size = Vector2(230.0 * scale_factor, 16.0 * scale_factor)
	_weapon_label.add_theme_font_size_override("font_size", maxi(7, roundi(8.0 * scale_factor)))
	_controls_hint.position = Vector2(margin, 80.0 * scale_factor)
	_controls_hint.size = Vector2(viewport_size.x - 2.0 * margin, 12.0 * scale_factor)
	_controls_hint.add_theme_font_size_override("font_size", maxi(7, roundi(8.0 * scale_factor)))
	_boss_panel.position = Vector2(margin, 105.0 * scale_factor)
	_boss_panel.size = Vector2(viewport_size.x - 2.0 * margin, 46.0 * scale_factor)
	_boss_track.size = Vector2(_boss_panel.size.x, 12.0 * scale_factor)
	_boss_fill.position = _boss_track.position
	_boss_fill.size = Vector2(_boss_track.size.x * _boss_health_ratio, _boss_track.size.y)
	_boss_label.size = Vector2(_boss_panel.size.x, 22.0 * scale_factor)
	_boss_label.add_theme_font_size_override("font_size", roundi(11.0 * scale_factor))
	_touch_controls.queue_redraw()


func _label(text: String, position: Vector2, dimensions: Vector2, font_size: int, color: Color) -> Label:
	var label := Label.new()
	label.text = text
	label.position = position
	label.size = dimensions
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", color)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return label
