extends CharacterBody2D
class_name RunnerController

signal health_changed(current: int, maximum: int)
signal player_died
signal attack_performed
signal dodge_started
signal weapon_changed(display_name: String, weapon_id: StringName)

const WEAPON_CONFIGS := [
	preload("res://resources/weapons/dungeon_edge.tres"),
	preload("res://resources/weapons/warden_crossbow.tres"),
]
const PLAYER_SWORD_PATH := "res://assets/weapons/dungeon_edge_sword.png"
const PLAYER_CROSSBOW_PATH := "res://assets/weapons/warden_crossbow.png"
const SWORD_SLASH_PATH := "res://assets/weapons/sword_slash.png"
const MELEE_IMPACT_PATH := "res://assets/weapons/melee_impact.png"
const PLAYER_ANIMATIONS := {
	"idle": {"path": "res://assets/player/idle.png", "frames": 4, "fps": 6.0, "loop": true},
	"walk": {"path": "res://assets/player/walk.png", "frames": 8, "fps": 12.0, "loop": true},
	"melee_attack": {"path": "res://assets/player/melee_attack.png", "frames": 6, "fps": 24.0, "loop": false},
	"ranged_attack": {"path": "res://assets/player/ranged_attack.png", "frames": 6, "fps": 18.0, "loop": false},
	"hurt": {"path": "res://assets/player/hurt.png", "frames": 3, "fps": 16.0, "loop": false},
	"death": {"path": "res://assets/player/death.png", "frames": 6, "fps": 12.0, "loop": false},
	"dodge": {"path": "res://assets/player/dodge.png", "frames": 4, "fps": 20.0, "loop": false},
}

var max_health: int = 100
var health: int = 100
var attack_damage: int = 10
var movement_speed: float = 200.0
var _sword_damage_multiplier := 1.0
var _crossbow_damage_multiplier := 1.0
var _audio_manager: GameAudioManager
var touch_controls: Node
var controls_enabled: bool = true
var is_alive: bool = true

var _active_weapon_index := 0
var _weapon_cooldowns: Dictionary = {}
var _facing := Vector2.DOWN
var _dodge_direction := Vector2.DOWN
var _dodge_time := 0.0
var _invulnerability_time := 0.0
var _dodge_cooldown := 0.0
var _footstep_time := 0.0
var _melee_windup_time := 0.0
var _melee_active_time := 0.0
var _melee_window_open := false
var _melee_hit_registered := false
var _melee_damage := 1
var _action_animation: StringName = &""
var _death_signal_pending := false
var _slash_time := 0.0
var _melee_impact_time := 0.0

@onready var _animated_sprite := $AnimatedSprite2D as AnimatedSprite2D
@onready var _sword_sprite := $SwordSprite as Sprite2D
@onready var _crossbow_sprite := $CrossbowSprite as Sprite2D
@onready var _melee_hitbox := $MeleeHitbox as Area2D
@onready var _slash_effect := $SlashEffect as Sprite2D
@onready var _melee_impact_effect := $MeleeImpactEffect as Sprite2D


func _ready() -> void:
	_audio_manager = get_node("/root/AudioManager") as GameAudioManager
	_animated_sprite.sprite_frames = _build_sprite_frames()
	_animated_sprite.animation_finished.connect(_on_sprite_animation_finished)
	_melee_hitbox.body_entered.connect(_on_melee_hitbox_body_entered)
	_animated_sprite.play("idle")
	_setup_weapon_art()
	for weapon in WEAPON_CONFIGS:
		_weapon_cooldowns[weapon.weapon_id] = 0.0
	_update_equipped_sprites()
	add_to_group("player")
	var camera := get_node_or_null("Camera2D") as Camera2D
	if camera != null:
		camera.limit_left = 0
		camera.limit_right = 540
		camera.limit_top = 0
		camera.limit_bottom = 1000
	health_changed.emit(health, max_health)


func configure(stats: Dictionary, controls: Node) -> void:
	max_health = maxi(1, int(stats.get("max_health", 100)))
	health = max_health
	attack_damage = maxi(1, int(stats.get("attack_damage", 10)))
	movement_speed = clampf(float(stats.get("move_speed", 200.0)), 80.0, 400.0)
	_sword_damage_multiplier = clampf(float(stats.get("sword_damage_multiplier", 1.0)), 1.0, 2.0)
	_crossbow_damage_multiplier = clampf(float(stats.get("crossbow_damage_multiplier", 1.0)), 1.0, 2.0)
	touch_controls = controls
	is_alive = true
	controls_enabled = true
	_active_weapon_index = 0
	for weapon in WEAPON_CONFIGS:
		_weapon_cooldowns[weapon.weapon_id] = 0.0
	_update_equipped_sprites()
	health_changed.emit(health, max_health)


func set_controls_enabled(enabled: bool) -> void:
	controls_enabled = enabled
	if not enabled:
		velocity = Vector2.ZERO
		_end_melee_attack()
		queue_redraw()


func request_attack() -> void:
	var weapon := _current_weapon()
	if not controls_enabled or not is_alive or float(_weapon_cooldowns.get(weapon.weapon_id, 0.0)) > 0.0:
		return

	if not _play_action_animation(weapon.attack_animation):
		return

	_weapon_cooldowns[weapon.weapon_id] = weapon.cooldown
	if weapon.projectile_scene == null:
		_start_melee_attack(weapon)
	else:
		_fire_projectile(weapon)
	attack_performed.emit()
	queue_redraw()

func switch_weapon() -> void:
	if not controls_enabled or not is_alive:
		return
	_end_melee_attack()
	_active_weapon_index = (_active_weapon_index + 1) % WEAPON_CONFIGS.size()
	_update_equipped_sprites()
	var weapon := _current_weapon()
	weapon_changed.emit(weapon.display_name, weapon.weapon_id)


func get_current_weapon_id() -> StringName:
	return _current_weapon().weapon_id


func get_current_weapon_name() -> String:
	return _current_weapon().display_name


func _current_weapon() -> WeaponConfig:
	return WEAPON_CONFIGS[_active_weapon_index] as WeaponConfig


func _update_equipped_sprites() -> void:
	if _sword_sprite == null or _crossbow_sprite == null:
		return
	var is_sword_equipped := _active_weapon_index == 0
	_sword_sprite.visible = is_sword_equipped
	_crossbow_sprite.visible = not is_sword_equipped
	_sword_sprite.position = _facing * 22.0
	_sword_sprite.rotation = _facing.angle() - PI * 0.5
	_crossbow_sprite.position = _facing * 18.0
	_crossbow_sprite.rotation = _facing.angle() - PI * 0.5


func _start_melee_attack(weapon: WeaponConfig) -> void:
	_melee_hit_registered = false
	_melee_window_open = false
	_melee_damage = maxi(1, roundi(attack_damage * weapon.damage_multiplier * _sword_damage_multiplier))
	_melee_windup_time = weapon.windup_time
	_melee_active_time = 0.0
	_melee_hitbox.position = _facing * weapon.hitbox_offset
	_melee_hitbox.rotation = _facing.angle() - PI * 0.5
	_melee_hitbox.set_deferred("monitoring", false)
	_show_slash_effect()


func _end_melee_attack() -> void:
	_melee_windup_time = 0.0
	_melee_active_time = 0.0
	_melee_window_open = false
	if _melee_hitbox != null:
		_melee_hitbox.set_deferred("monitoring", false)


func _fire_projectile(weapon: WeaponConfig) -> void:
	var projectile := weapon.projectile_scene.instantiate() as CrossbowProjectile
	if projectile == null:
		push_error("The configured projectile scene could not be instantiated.")
		return
	projectile.name = "CrossbowProjectile"
	projectile.configure(
		_facing,
		roundi(attack_damage * weapon.damage_multiplier * _crossbow_damage_multiplier),
		weapon.projectile_speed,
		weapon.projectile_range
	)
	get_parent().add_child(projectile)
	projectile.global_position = global_position + _facing * 24.0


func _on_melee_hitbox_body_entered(body: Node2D) -> void:
	if not _melee_window_open or _melee_hit_registered:
		return
	if not body.is_in_group("enemies") or not body.has_method("take_damage"):
		return
	_melee_hit_registered = true
	body.call("take_damage", _melee_damage)
	_show_impact_effect(_melee_impact_effect, to_local(body.global_position), 0.045)


func _setup_weapon_art() -> void:
	_sword_sprite.texture = load(PLAYER_SWORD_PATH) as Texture2D
	_crossbow_sprite.texture = load(PLAYER_CROSSBOW_PATH) as Texture2D
	_slash_effect.texture = load(SWORD_SLASH_PATH) as Texture2D
	_melee_impact_effect.texture = load(MELEE_IMPACT_PATH) as Texture2D
	for weapon_sprite in [_sword_sprite, _crossbow_sprite, _slash_effect, _melee_impact_effect]:
		if weapon_sprite.texture == null:
			push_error("A player weapon texture could not be loaded: %s" % weapon_sprite.name)
		weapon_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_sword_sprite.scale = Vector2(0.025, 0.025)
	_crossbow_sprite.scale = Vector2(0.025, 0.025)
	_slash_effect.scale = Vector2(0.045, 0.045)
	_slash_effect.visible = false
	_melee_impact_effect.scale = Vector2.ZERO
	_melee_impact_effect.visible = false


func _show_slash_effect() -> void:
	_slash_effect.position = _facing * 27.0
	_slash_effect.rotation = _facing.angle()
	_slash_effect.modulate = Color.WHITE
	_slash_effect.visible = true
	_slash_time = 0.18


func _show_impact_effect(effect: Sprite2D, offset: Vector2, sprite_scale: float) -> void:
	effect.position = offset
	effect.scale = Vector2(sprite_scale, sprite_scale)
	effect.modulate = Color.WHITE
	effect.visible = true
	_melee_impact_time = 0.16


func request_dodge() -> void:
	if not controls_enabled or not is_alive or _dodge_cooldown > 0.0:
		return

	var direction := _movement_input()
	if direction.length_squared() < 0.01:
		direction = _facing
	_dodge_direction = direction.normalized()
	_dodge_time = 0.18
	_invulnerability_time = 0.34
	_dodge_cooldown = 1.35
	_play_action_animation(&"dodge")
	dodge_started.emit()
	queue_redraw()


func take_damage(amount: int) -> void:
	if not is_alive or _invulnerability_time > 0.0 or amount <= 0:
		return

	health = maxi(0, health - amount)
	_end_melee_attack()
	health_changed.emit(health, max_health)
	queue_redraw()
	if health == 0:
		is_alive = false
		velocity = Vector2.ZERO
		controls_enabled = false
		_death_signal_pending = _play_action_animation(&"death")
		if not _death_signal_pending:
			player_died.emit()
	else:
		_play_action_animation(&"hurt")


func build_run_record() -> Dictionary:
	return {
		"max_health": max_health,
		"attack_damage": maxi(
			roundi(attack_damage * _sword_damage_multiplier),
			roundi(attack_damage * _crossbow_damage_multiplier)
		),
		"move_speed": movement_speed,
		"weapon_archetypes": ["dungeon_edge", "warden_crossbow"],
		"equipped_weapon": String(_current_weapon().weapon_id),
	}


func _physics_process(delta: float) -> void:
	for weapon_id in _weapon_cooldowns:
		_weapon_cooldowns[weapon_id] = maxf(0.0, float(_weapon_cooldowns[weapon_id]) - delta)
	if _melee_windup_time > 0.0:
		_melee_windup_time = maxf(0.0, _melee_windup_time - delta)
		if _melee_windup_time == 0.0 and controls_enabled and is_alive:
			_melee_window_open = true
			_melee_active_time = _current_weapon().active_time
			_melee_hitbox.set_deferred("monitoring", true)
	if _melee_window_open:
		_melee_active_time = maxf(0.0, _melee_active_time - delta)
		if _melee_active_time == 0.0:
			_end_melee_attack()
	_dodge_cooldown = maxf(0.0, _dodge_cooldown - delta)
	_invulnerability_time = maxf(0.0, _invulnerability_time - delta)
	_footstep_time = maxf(0.0, _footstep_time - delta)
	_slash_time = maxf(0.0, _slash_time - delta)
	_melee_impact_time = maxf(0.0, _melee_impact_time - delta)
	_slash_effect.modulate.a = _slash_time / 0.18
	_melee_impact_effect.modulate.a = _melee_impact_time / 0.16
	if _slash_time == 0.0:
		_slash_effect.visible = false
	if _melee_impact_time == 0.0:
		_melee_impact_effect.visible = false
	_animated_sprite.modulate = Color("d3fff2") if _invulnerability_time > 0.0 else Color.WHITE

	if not controls_enabled or not is_alive:
		velocity = Vector2.ZERO
		move_and_slide()
		_update_sprite_animation()
		queue_redraw()
		return

	var movement := _movement_input()
	if movement.length_squared() > 0.01:
		_facing = movement.normalized()
	_update_equipped_sprites()

	if Input.is_action_just_pressed("attack"):
		request_attack()
	if Input.is_action_just_pressed("switch_weapon"):
		switch_weapon()
	if Input.is_action_just_pressed("dodge"):
		request_dodge()

	if _dodge_time > 0.0:
		_dodge_time = maxf(0.0, _dodge_time - delta)
		velocity = _dodge_direction * movement_speed * 3.2
	else:
		velocity = movement * movement_speed

	move_and_slide()
	_update_sprite_animation()
	if velocity.length_squared() > 900.0 and _dodge_time <= 0.0 and _footstep_time <= 0.0:
		_audio_manager.play_sfx("footstep")
		_footstep_time = 0.38
	queue_redraw()


func _movement_input() -> Vector2:
	var movement := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	if touch_controls != null and touch_controls.has_method("get_movement_vector"):
		var touch_movement: Vector2 = touch_controls.call("get_movement_vector")
		if touch_movement.length_squared() > movement.length_squared():
			movement = touch_movement
	return movement.limit_length(1.0)


func _build_sprite_frames() -> SpriteFrames:
	var sprite_frames := SpriteFrames.new()
	sprite_frames.remove_animation("default")

	for animation_key in PLAYER_ANIMATIONS:
		var animation_name := StringName(animation_key)
		var config: Dictionary = PLAYER_ANIMATIONS[animation_key]
		var texture := load(str(config["path"])) as Texture2D
		if texture == null:
			push_error("Could not load player animation sheet: %s" % config["path"])
			continue

		sprite_frames.add_animation(animation_name)
		sprite_frames.set_animation_speed(animation_name, float(config["fps"]))
		sprite_frames.set_animation_loop(animation_name, bool(config["loop"]))
		var frame_count := int(config["frames"])
		for frame_index in frame_count:
			var start_x := floori(float(frame_index) * texture.get_width() / frame_count)
			var end_x := floori(float(frame_index + 1) * texture.get_width() / frame_count)
			var frame := AtlasTexture.new()
			frame.atlas = texture
			frame.region = Rect2(start_x, 0, end_x - start_x, texture.get_height())
			sprite_frames.add_frame(animation_name, frame)

	if not sprite_frames.has_animation("idle"):
		push_error("The player idle animation is unavailable.")
	return sprite_frames


func _play_action_animation(animation: StringName) -> bool:
	if _animated_sprite.sprite_frames == null or not _animated_sprite.sprite_frames.has_animation(animation):
		push_error("Player animation is not available: %s" % animation)
		return false
	_action_animation = animation
	_animated_sprite.play(animation)
	return true


func _update_sprite_animation() -> void:
	_animated_sprite.flip_h = _facing.x < -0.01
	if _action_animation != &"":
		return
	var next_animation: StringName = &"walk" if velocity.length_squared() > 0.01 else &"idle"
	if _animated_sprite.animation != next_animation:
		_animated_sprite.play(next_animation)


func _on_sprite_animation_finished() -> void:
	if _action_animation == &"death":
		if _death_signal_pending:
			_death_signal_pending = false
			player_died.emit()
		return
	_action_animation = &""
	_update_sprite_animation()


func _draw() -> void:
	draw_circle(Vector2(0, 7), 22, Color(0.008, 0.016, 0.022, 0.48))
	if _dodge_time > 0.0:
		draw_arc(Vector2.ZERO, 25, 0.0, TAU, 28, Color(0.43, 0.9, 0.78, 0.8), 2.0, true)
