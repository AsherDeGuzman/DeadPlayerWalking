extends Area2D
class_name CrossbowProjectile

const IMPACT_DURATION := 0.2

var direction := Vector2.RIGHT
var damage := 1
var speed := 720.0
var maximum_distance := 520.0
var target_group: StringName = &"enemies"
var _distance_travelled := 0.0
var _resolved := false

@onready var _projectile_sprite := $ProjectileSprite as Sprite2D
@onready var _impact_sprite := $ImpactSprite as Sprite2D


func _ready() -> void:
	body_entered.connect(_on_body_entered)
	_impact_sprite.visible = false
	_projectile_sprite.rotation = direction.angle()


func configure(
	projectile_direction: Vector2,
	projectile_damage: int,
	projectile_speed: float,
	projectile_range: float,
	project_group: StringName = &"enemies"
) -> void:
	direction = projectile_direction.normalized()
	if direction.length_squared() < 0.01:
		direction = Vector2.DOWN
	damage = maxi(1, projectile_damage)
	speed = maxf(1.0, projectile_speed)
	maximum_distance = maxf(1.0, projectile_range)
	target_group = project_group
	set_collision_mask_value(1, target_group == &"player")
	set_collision_mask_value(2, target_group == &"enemies")
	set_collision_mask_value(3, true)


func _physics_process(delta: float) -> void:
	if _resolved:
		return
	var step_distance := speed * delta
	global_position += direction * step_distance
	_distance_travelled += step_distance
	if _distance_travelled >= maximum_distance:
		queue_free()


func _on_body_entered(body: Node2D) -> void:
	if _resolved:
		return
	if body.is_in_group(target_group) and body.has_method("take_damage"):
		body.call("take_damage", damage)
	_resolved = true
	set_deferred("monitoring", false)
	_projectile_sprite.visible = false
	_impact_sprite.visible = true
	var tween := create_tween()
	tween.tween_property(_impact_sprite, "modulate:a", 0.0, IMPACT_DURATION)
	tween.tween_callback(queue_free)
