extends Node2D
class_name Level01Controller

signal choice_requested(choice_kind: String)
signal level_finished(completed: bool, record: Dictionary)
signal pause_requested
signal floor5_reveal_completed

@export var player_scene: PackedScene
@export var enemy_scene: PackedScene
@export var previous_self_scene: PackedScene
@export var room_scene: PackedScene
@export var boss_scene: PackedScene

const FLOOR_DEFINITIONS := [
	preload("res://resources/dungeon/floor_01.tres"),
	preload("res://resources/dungeon/floor_02.tres"),
	preload("res://resources/dungeon/floor_03.tres"),
	preload("res://resources/dungeon/floor_04.tres"),
	preload("res://resources/dungeon/floor_05.tres"),
	preload("res://resources/dungeon/floor_06.tres"),
	preload("res://resources/dungeon/floor_07.tres"),
	preload("res://resources/dungeon/floor_08.tres"),
	preload("res://resources/dungeon/floor_09.tres"),
	preload("res://resources/dungeon/floor_10.tres"),
]

var run_stats: Dictionary = {}
var saved_echoes: Array[Dictionary] = []
var run_number: int = 1
var points_total: int = 0
var should_reveal_floor5 := true

var _player: RunnerController
var _hud: CanvasLayer
var _audio_manager: GameAudioManager
var _touch_controls: TouchControls
var _room_container: Node2D
var _current_room: DungeonRoom
var _floor_index := 0
var _room_index := 0
var _transition_pending := false
var _run_over := false


func _process(_delta: float) -> void:
	if _current_room != null and _current_room.is_exit_unlocked() and _current_room.is_player_at_exit(_player):
		_on_room_exit_entered()


func _ready() -> void:
	set_process(false)
	_audio_manager = get_node("/root/AudioManager") as GameAudioManager
	_player = $Player as RunnerController
	_hud = $HUD as CanvasLayer
	_room_container = $Rooms as Node2D
	if room_scene == null or enemy_scene == null:
		push_error("The dungeon scene requires room and enemy scenes.")
		return

	if run_stats.is_empty():
		run_stats = {"max_health": 100, "attack_damage": 10, "move_speed": 200.0}

	_touch_controls = _hud.call("get_touch_controls") as TouchControls
	_player.configure(run_stats, _touch_controls)
	_player.health_changed.connect(func(current: int, maximum: int) -> void:
		_hud.call("set_health", current, maximum)
		_on_player_health_changed(current)
	)
	_player.attack_performed.connect(_audio_manager.play_sfx.bind("attack"))
	_player.dodge_started.connect(_audio_manager.play_sfx.bind("dash"))
	_player.player_died.connect(_on_player_died)
	_player.weapon_changed.connect(_hud.set_weapon)
	_player.position = Vector2(270.0, 870.0)
	_hud.call("set_health", _player.health, _player.max_health)
	_hud.call("set_weapon", _player.get_current_weapon_name(), _player.get_current_weapon_id())
	_hud.call("set_points", points_total)

	if _touch_controls != null:
		_touch_controls.attack_pressed.connect(_player.request_attack)
		_touch_controls.weapon_switch_pressed.connect(_player.switch_weapon)
		_touch_controls.dodge_pressed.connect(_player.request_dodge)
		_touch_controls.interact_pressed.connect(_try_interact)
		_hud.pause_pressed.connect(func() -> void: pause_requested.emit())

	_load_current_room()


func get_current_floor_number() -> int:
	return _floor_index + 1


func get_current_room_number() -> int:
	return _room_index + 1


func get_current_room() -> DungeonRoom:
	return _current_room


func set_choice_paused(paused: bool) -> void:
	if _player != null:
		_player.set_controls_enabled(not paused)


func choose_route(_route: String) -> void:
	push_warning("Route selection is not part of the ten-floor dungeon flow.")


func choose_previous_self(_response: String) -> void:
	push_warning("Previous-self encounters use stat snapshots and do not have a pre-fight response choice.")


func _load_current_room() -> void:
	set_process(false)
	var floor_definition := FLOOR_DEFINITIONS[_floor_index] as FloorDefinition
	_current_room = room_scene.instantiate() as DungeonRoom
	if _current_room == null:
		push_error("The configured room scene is not a DungeonRoom.")
		return
	var echo_snapshot: Dictionary = saved_echoes.back() if not saved_echoes.is_empty() else {}
	_current_room.configure(
		floor_definition,
		_room_index,
		_player,
		enemy_scene,
		previous_self_scene,
		boss_scene,
		echo_snapshot,
		_get_room_layout_seed()
	)
	_current_room.room_cleared.connect(_on_room_cleared)
	_current_room.exit_entered.connect(_on_room_exit_entered)
	_current_room.boss_encounter_started.connect(_on_boss_encounter_started)
	_current_room.boss_health_changed.connect(_hud.set_boss_health)
	_current_room.boss_defeated.connect(_on_boss_defeated)
	_room_container.add_child(_current_room)
	_player.position = Vector2(270.0, 870.0)
	_player.velocity = Vector2.ZERO
	_update_hud_location(floor_definition)


func _get_room_layout_seed() -> int:
	var seed := _room_index
	for previous_floor_index in range(_floor_index):
		var previous_floor := FLOOR_DEFINITIONS[previous_floor_index] as FloorDefinition
		seed += previous_floor.room_count
	return seed


func _on_room_cleared(floor_number: int, room_number: int) -> void:
	set_process(not _run_over)
	_audio_manager.play_sfx("enemy_down")
	_hud.call("set_zone", "FLOOR %02d  /  ROOM %02d CLEARED" % [floor_number, room_number])


func _on_boss_encounter_started(boss: DungeonBoss) -> void:
	if boss.boss_id == &"previous_self" and should_reveal_floor5:
		_play_floor5_reveal(boss)
	else:
		boss.start_encounter()


func _play_floor5_reveal(boss: DungeonBoss) -> void:
	should_reveal_floor5 = false
	_player.set_controls_enabled(false)
	_hud.show_floor5_reveal()
	var camera := _player.get_node_or_null("Camera2D") as Camera2D
	var original_zoom := camera.zoom if camera != null else Vector2.ONE
	if camera != null:
		camera.zoom = Vector2(0.85, 0.85)
	boss.position = Vector2(270.0, 150.0)
	boss.modulate = Color(1.0, 1.0, 1.0, 0.0)
	var entrance := create_tween()
	entrance.set_parallel(true)
	entrance.tween_property(boss, "position:y", 330.0, 1.15).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	entrance.tween_property(boss, "modulate:a", 1.0, 0.9)
	await entrance.finished
	if _run_over:
		return
	_hud.hide_floor5_reveal()
	if camera != null:
		camera.zoom = original_zoom
	_player.set_controls_enabled(true)
	if is_instance_valid(boss):
		boss.start_encounter()
	floor5_reveal_completed.emit()


func _on_boss_defeated(boss_id: StringName) -> void:
	_hud.hide_boss_health()
	if boss_id == &"hollow_warden":
		_finish_run(true)


func _on_room_exit_entered() -> void:
	if _run_over or _transition_pending or _current_room == null or not _current_room.is_exit_unlocked():
		return
	_transition_pending = true
	set_process(false)
	call_deferred("_advance_from_exit")


func _advance_from_exit() -> void:
	if _run_over or _current_room == null or not _current_room.is_exit_unlocked():
		_transition_pending = false
		set_process(_current_room != null and _current_room.is_exit_unlocked())
		return
	var floor_definition := FLOOR_DEFINITIONS[_floor_index] as FloorDefinition
	if _room_index + 1 < floor_definition.room_count:
		_room_index += 1
	elif _floor_index + 1 < FLOOR_DEFINITIONS.size():
		_floor_index += 1
		_room_index = 0
	else:
		_finish_run(true)
		_transition_pending = false
		return
	_current_room.queue_free()
	_current_room = null
	_load_current_room()
	_transition_pending = false


func _update_hud_location(floor_definition: FloorDefinition) -> void:
	_hud.call(
		"set_zone",
		"FLOOR %02d / 10  ·  %s  ·  ROOM %02d / %02d" % [
			floor_definition.floor_number,
			floor_definition.floor_name.to_upper(),
			_room_index + 1,
			floor_definition.room_count,
		]
	)


func _try_interact() -> void:
	if _current_room != null and _current_room.is_exit_unlocked() and _current_room.is_player_at_exit(_player):
		_on_room_exit_entered()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("interact"):
		_try_interact()


func _on_player_health_changed(current: int) -> void:
	if current < _player.max_health:
		_audio_manager.play_sfx("damage")


func _on_player_died() -> void:
	_finish_run(false)


func _finish_run(completed: bool) -> void:
	if _run_over:
		return
	_run_over = true
	set_process(false)
	_player.set_controls_enabled(false)
	_audio_manager.play_sfx("victory" if completed else "defeat")
	level_finished.emit(completed, _player.build_run_record())
