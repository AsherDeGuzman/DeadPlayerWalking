# DEAD PLAYER WALKING

## GAME DESIGN DOCUMENT · SECTIONS I–VIII

**Studio:** Tokens  
**Project:** Dead Player Walking  
**Course:** GAMDES1 — Game Design and Development  
**Team:** De Guzman, Asher Nathaniel E.; Macaraeg, Mark Cyrus P.; Zapanta, Zeus Levi C.  
**Build:** Godot 4.7.1-stable · 2D top-down · mobile-first  
**Revision:** 30 October 2026

> **Template note:** The supplied midterm handout is an assessment rubric, not GDD Template 2627A. The original project GDD PDFs were available, but the school template itself was not. This consolidated revision uses a clearly structured print layout; it does not claim to reproduce the required template's fonts, page setup, or heading styles. Apply this content to the official template if its use is mandatory.

> **Testing note:** The project was checked with Godot 4.7.1 headless import, launch, and an automated integration test. No peer gallery walk, paper simulation, or human playtest results were supplied. Those results are intentionally not invented; collect and add them after the actual activities.

---

# I. GAME OVERVIEW

## 1.1 High-concept statement and elevator pitch

**High concept.** *Dead Player Walking* is a mobile-first, single-player top-down action roguelike about a survivor escaping a sealed, decaying combat facility. The survivor attacks, dodges, and learns from a linear sequence of encounters; after a death, a recorded version of the survivor returns as an AI-controlled previous self in a later run.

**Elevator pitch.** A survivor wakes in an abandoned facility where the way out is guarded by combatants, live hazards, and the memory of earlier failed attempts. Move through readable rooms, attack, and dash through telegraphed danger. At each run’s fork, take the longer, safer supply route or risk a hazardous shortcut. If a run ends in death, the game records the survivor’s movement and combat choices. A previous version can later replay those movements as an opponent, so an earlier tactic becomes part of the next challenge. Reaching the exit earns 30 scrap; death still earns 10. Spend scrap between runs on permanent health, damage, or speed upgrades. Runs are deterministic: every hazard, encounter, and reward can be learned and reproduced. The experience is designed for solo players who enjoy readable action, deliberate risk, short-form exploration, and progression shaped by their own play.

## 1.2 Genre, platform, and audience

| Element | Design |
|---|---|
| Genre | Single-player, top-down 2D action roguelike; fixed encounters and persistent between-run progression |
| Primary platform | Mobile; portrait 540 × 960 logical viewport; touch movement pad and action buttons |
| Development and validation platform | Windows x64; Godot 4.7.1-stable |
| Intended audience | Players who enjoy short action encounters, pattern learning, exploration, and persistent upgrades |
| Players | One human player; ordinary enemies and recorded previous selves are AI controlled |

## 1.3 Target experience

Players should recognize that movement creates safety, a warning precedes a hazard strike, and a previous self behaves like a trace of an earlier run. A death should still contribute modestly to progression. The game aims for understandable challenge, discovery through environmental details, and the narrative surprise of facing one’s past—not multiplayer competition or unpredictable reward hunting.

## 1.4 Scope and feasibility

| In scope for this build | Out of scope for this build | Feasibility |
|---|---|---|
| One complete, deterministic, linear facility level with an exit and working win and death outcomes | Multiple biomes, generated levels, online play, multiplayer, multiple endings | One level is sufficient to implement and verify the complete documented run loop |
| Screen-oriented top-down movement, keyboard alternatives, mobile touch controls, melee strike, and dodge | Character customization, complex animation trees, a separate camera-rotation control | Controls use Godot input actions and small procedural drawings rather than a large animation pipeline |
| Basic enemies, visible attacks, a deterministic telegraphed hazard, and at most one active previous self in an arena | Boss roster, large simultaneous enemy groups, randomized combat patterns | Fixed behavior supports the teaching order, reproduction of bugs, and a bounded first level |
| Three permanent upgrade types, saved scrap, and the three most recent valid death records | Skill trees, consumable equipment, healing pickups, unbounded historical records | Small ConfigFile saves and three capped records fit the project scope |
| A route choice and a previous-self response that reconverge | Branch-specific levels, a dialogue tree, cutscenes | Two short decision points create a visible trade-off without multiplying level content |
| Procedurally drawn character/world visuals and originally synthesized audio | Unlicensed asset packs or uncredited third-party media | The project needs no external asset package or add-on |

**Scope rationale.** A small student project can keep its camera, action rules, record format, fixed level, and testing burden manageable by developing the first run end to end. Multiplayer, randomized layouts, additional endings, and asset-heavy animation remain explicit cuts rather than promised features.

# II. FORMAL ELEMENTS

## 2.1 Players, objectives, rules, procedures, resources, conflict, boundaries, and outcome

| Element | Dead Player Walking |
|---|---|
| Players | One player controls one survivor using touch controls or keyboard. Ordinary enemies and previous selves are AI controlled. |
| Objectives | Reach the facility exit; survive the fixed encounters; build scrap; improve permanent stats; learn to defeat earlier versions of the survivor. |
| Rules | A run starts at the entry with current upgraded maximum health. Stay inside the rectangular facility. Movement is screen-oriented. A strike deals the current attack damage to at most one eligible nearby enemy. A dash moves in the selected direction and briefly grants invulnerability; it has a cooldown. Visible wind-ups and the live-conduit warning provide response time. Health at zero ends the run. Clearing the final arena and reaching the exit wins it. Exactly one run reward is granted: 30 scrap for a win, 10 for death. Scrap cannot be negative. Upgrade prices are 20 scrap for +10 maximum HP, 25 for +2 attack damage, and 20 for +10 movement speed. A death can record the run; at most three valid records are retained. The most recent valid record supplies the next previous self. |
| Procedures | Open the facility log; start a run; learn movement in the entry; choose the supply route or hazardous shortcut; clear two basic enemies; read and dodge the fixed hazard; pass through the enemy-free recovery room; if a record exists, choose how to respond to one previous self; defeat the final encounter; reach or interact with the exit; receive one outcome reward; purchase any affordable permanent upgrade; start again. |
| Resources | Health is reset to the current maximum for each run. Scrap persists between runs. Upgrade levels persist. Recorded actions and their run statistics persist separately from scrap and are used to instantiate an echo. Strike and dodge are limited by their visible cooldowns. |
| Conflict | Ordinary walkers pursue and attack after a visible wind-up. The fixed conduit hazard damages a player who remains in its strike lane. Previous selves carry run-specific stats and replay recorded movement and action samples, then use bounded fallback pursuit after the recorded sequence. |
| Boundaries | This is a single-player game in a bounded level. Solid facility walls prevent leaving the playable space. Its encounter sequence is fixed; there are no random drops or online services. |
| Outcome | Win: clear the final encounter, reach the exit objective, receive 30 scrap, and open the between-run workshop. Death: health reaches zero, end the run, receive 10 scrap, save usable run data for future echoes, and open the same workshop. Both outcomes permit a next run. |

## 2.2 Input–action–feedback

| Input | In-game action | Immediate feedback |
|---|---|---|
| Virtual movement pad; WASD; arrow keys | Screen-oriented movement and positioning | Survivor moves against the fixed floor grid; collision stops movement at solid boundaries |
| STRIKE; Space; J | Melee attack with cooldown | Strike arc, generated attack sound, enemy health reduction and hit flash, or defeat sound |
| DASH; Shift; K | Short evasive reposition with cooldown | Fast movement, invulnerability ring, generated dash sound |
| USE; E; Enter | Interact with a cleared exit in range | Run-completion state and generated victory cue |
| II pause button; Escape; P | Pause or resume the active run | World and facility ambience pause; a resume/end-run menu appears |

# III. MDA AND PLAYER EXPERIENCE

## 3.1 Mechanics, dynamics, aesthetics, and targeted fun

| Mechanics | Resulting dynamics | Intended player experience |
|---|---|---|
| Screen-oriented movement, solid boundaries, one fixed camera | Look ahead, reposition around walls, and keep both the player and local threats in view | **Challenge:** deliberate positioning and responsive evasion |
| A cooldown strike, visible enemy wind-up, and non-random enemy pursuit | Observe an attack cue, create distance, then counterattack | **Mastery:** learn a repeatable pattern rather than depend on luck |
| A time-limited dash with short invulnerability | Trade a cooldown for escape through a tight moment | **Challenge:** time a limited defensive action |
| A visible supply route versus an exposed shortcut | Trade a longer covered path for one avoidable, warned hazard | **Discovery and agency:** express a risk preference with a gameplay consequence |
| Environmental traces, abandoned supplies, impact marks, and recorded action echoes | Infer past failure from spaces and later recognize one's own tactics in an opponent | **Narrative:** understand that every death leaves a trace |
| Fixed rewards and three upgrade choices between runs | Compare current scrap to transparent costs; choose health, damage, or speed | **Mastery and progression:** convert failure or success into a lasting, comprehensible improvement |

The primary targeted kinds of fun are **challenge**, **discovery**, and **narrative**. These follow from the listed movement/combat demands, reconverging route choice and environmental evidence, and playable echoes. Large-scale social competition is **deliberately not pursued** in this single-player, offline prototype.

## 3.2 Player types and motivation

Using Bartle's player-type model as a cautious design lens, the game primarily accommodates **achiever-oriented** motivation through fixed objectives, measurable encounter clearing, predictable rewards, and permanent upgrades; **explorer-oriented** motivation through two route choices and facility details; and **killer-oriented** motivation only in the limited sense of defeating ordinary and previous-self enemies. The model was developed for multi-user environments, so these labels are design hypotheses for a solo game, not a measured audience classification (Bartle, 1996). Socializer-oriented multiplayer features are intentionally out of scope.

## 3.3 Player-experience goals and playtest observations

These are measurable **future playtest targets**, not claims of completed human testing.

| Moment | Desired experience | Feature producing it | How to observe it in a human playtest |
|---|---|---|---|
| Entry and movement room | Understand movement and the visible level boundary | Safe initial room, screen-oriented controls, solid walls | Ask the player to reach the next room; record unprompted navigation and boundary confusion |
| Live-conduit room | Notice a cue and reposition rather than stand in the beam | Fixed warning-to-strike timing, readable beam, dodge cooldown | Count whether the player leaves the marked lane before its strike; ask what signaled danger |
| Route fork | Understand the different safety/risk trade-offs | Labeled covered supply route and hazardous shortcut | Ask the player to predict each choice's cost before selection; record route selections |
| Previous-self arena | Recognize the earlier-run character and understand its threat | Differently colored echo, replayed action samples, a single isolated introduction | Ask what the echo represents and whether its attack behavior was readable |
| Outcome and workshop | Understand that both success and failure can earn progress | Explicit win/lose outcome, exact reward, visible upgrade prices and effects | Ask the player to state the awarded scrap and the next affordable upgrade |

## 3.4 Design risks

| Risk | Mitigation in the build |
|---|---|
| The recovery room feels empty | It is brief, contains environmental evidence, and separates the hazard from the echo introduction |
| The final encounter overwhelms a first-time player | Fixed threat locations, limited enemy counts, visible attack wind-ups, a preceding checkpoint in the teaching sequence, and one echo |
| A player cannot tell the echo from an ordinary enemy | Distinct pink echo silhouette, echo label, visual outline, and dedicated synthesized sound |
| The mobile player's fingers cover the center | Movement control sits at the lower left and actions at the lower right; the encounter view remains central and portrait-oriented |

# IV. CORE GAMEPLAY LOOP

## 4.1 Core loop diagram and walkthrough

```text
TITLE / WORKSHOP → START RUN → EXPLORE FIXED LEVEL
                                  ↓
                    OBSERVE → MOVE / STRIKE / DASH
                                  ↓
                  CLEAR WALKERS / CONDUIT / ECHOES
                                  ↓
                             OUTCOME?
                  ┌───────────────┴──────────────┐
                  ↓                              ↓
         REACH CLEARED EXIT              HEALTH REACHES ZERO
                  ↓                              ↓
          +30 SCRAP / WIN              +10 SCRAP / RECORD RUN
                  └───────────────┬──────────────┘
                                  ↓
                      PERMANENT UPGRADE (OPTIONAL)
                                  ↓
                              NEXT RUN ↻
```

1. The player starts a run with persistent upgrades and full current maximum health.
2. The player explores the fixed facility and chooses the covered supply route or the hazardous shortcut.
3. Enemies and the conduit encourage the player to observe, strike, dodge, and reposition.
4. If a valid death record exists, one previous self is introduced in its own arena; later the final arena combines that echo with a small number of ordinary enemies.
5. Clearing the final arena and reaching the exit wins the level. Reducing health to zero loses the run.
6. The outcome screen shows the result and grants exactly 30 scrap for a win or 10 for a death. A death can add a bounded previous-self record.
7. The player may spend scrap in the shared workshop, then start another run.

The existing high-level GDD estimates a 5–15 minute target run duration. That duration has **not** been confirmed by timed human playtests; this compact prototype's actual duration remains to be measured.

## 4.2 Micro/macro loops and action classification

| Loop | Sequence | Relationship |
|---|---|---|
| Micro, during combat | Observe cue → move into position → strike or dash → read enemy response → reposition | Success in the moment-to-moment loop supports surviving the level |
| Macro, between attempts | Start run → explore and fight → win or die → receive reward → review upgrades and echo history → start next run | Carries currency, purchased stats, and death-run data forward |

**In-game:** move, explore, choose a route, observe hazards, attack, dodge, fight, survive, and reach/interact with the objective.  
**Between-run:** receive outcome rewards, inspect and purchase permanent upgrades, retain a death record, and start again.

# V. LEVEL DESIGN

## 5.1 Layout pattern and annotated map

The level uses a **mostly linear, vertically sequenced layout with one optional fork that reconverges**. This follows the combat loop's teaching needs: safe movement precedes ordinary enemies; a visible hazard and a brief recovery precede the signature previous-self encounter; the final room combines known threats. The route choice changes the approach without multiplying the entire level.

```text
NORTH / START
  1  ENTRY             safe start; practice movement and solid boundaries
  ↓
  2  ROUTE FORK         supply route (left, covered) OR shortcut (right, exposed)
  └─────────────────── both routes reconverge before first combat
  3  BASIC COMBAT       two fixed walkers at (355, 930) and (682, 1010)
  ↓                     combat gate opens when this encounter is cleared
  4  LIVE CONDUIT       telegraphed, deterministic beam at y = 1372
  ↓
  5  QUIET ROOM         short rest, opened medical kit and traces; no active enemies
  ↓
  6  PREVIOUS SELF      one most-recent death echo, if a saved record exists
  ↓
  7  FINAL ARENA        two ordinary enemies and, if available, one previous self
  ↓                     final gate opens after the arena enemies are cleared
  8  EXIT               reach y = 2950 or use the nearby objective after clearing
SOUTH / OBJECTIVE
```

The playable rectangle is x = 128–896 and y = 120–3020 world units. The zone sequence is y = 138–382 entry; 408–808 route fork; 824–1124 basic combat; 1150–1520 conduit; 1540–1760 recovery; 1780–2120 previous-self arena; 2180–2760 final arena; 2800–2990 exit. Rectangular dividers, fixed gates, wall obstacles, hazardous lane markings, the dropped/opened kit, scratches, contrasting echoes, and a marked exit make the spaces legible.

## 5.2 Pacing and difficulty curve

The 1–5 values below are provisional design targets, **not playtest measurements**.

| Zone | Main demand | Target | Beat and pacing |
|---|---|---:|---|
| 1. Entry | Learn movement and boundaries | 1.0 | Safe introduction |
| 2. Movement and fork | Reposition around walls; understand route choice | 1.5 | Gentle rise; covered route or warned risk |
| 3. Basic combat | Defeat two low-pressure walkers | 2.5 | Rising beat; demonstrate attack |
| 4. Dodge arena | Leave a visible deterministic hazard lane in time | 3.0 | Rising beat; demonstrate dodge/reposition |
| 5. Recovery | Briefly rest and notice facility traces | 1.0 | Deliberate release |
| 6. Previous-self arena | Read a familiar saved combat pattern | 4.0 | Strong rise; only one echo, and only if a record exists |
| 7. Final arena | Combine learned actions against two walkers and at most one echo | 5.0 | Peak with bounded threats |
| 8. Exit | Reach a cleared objective | 1.0 | Release and run completion |

**Flow-channel fit point:** zone 6. Movement, basic attacks, and dodging have already been introduced before the first recorded echo.  
**Boredom risk:** a long empty recovery room could interrupt momentum; it remains compact and contains story evidence.  
**Anxiety/frustration risk:** an echo combined with too many ordinary enemies could obscure attack cues; the earlier echo encounter is solo, the final threat count is capped, and all enemies use readable attack wind-ups.

## 5.3 Teaching mechanics without tutorial popups

| Mechanic | Introduction point | Teaching method |
|---|---|---|
| Move and stay in bounds | Zones 1–2 | A safe open room leads to restrictive, visible walls and an obstacle |
| Choose a route | Zone 2 | Environmental route labels show the covered path and exposed, warned shortcut before selection |
| Strike | Zone 3 | Fixed weak enemies block progress; strike arc and enemy reactions confirm accepted hits |
| Dodge/reposition | Zone 4 | Beam markings and warning sound precede a repeatable strike; no popup is required to see cause and effect |
| Read a previous self | Zone 6, if a death record exists | A single high-contrast echo appears in a clear arena; a diegetic sound and optional response choice reinforce recognition |
| Combine familiar mechanics | Zone 7 | Limited fixed threats combine movement, strike, and dodge in one encounter |

# VI. SYSTEMS AND BALANCE

## 6.1 Resource economy

| Resource | Starting value | Source / gain | Sink / use | Guardrail |
|---|---:|---|---|---|
| Scrap | 0 on a new save | +30 after a win; +10 after a death | Purchase permanent upgrades | Grant exactly once per run; currency never becomes negative |
| Health | 100 HP before upgrades | Reset to current permanent maximum at the beginning of each run | Ordinary enemy attacks (8 base damage), previous-self attacks (recorded player damage, base 10), and the fixed conduit or shortcut hazard (14 or 12) | No healing pickups are implemented; dodge grants only a brief invulnerability window |
| Maximum health upgrade | Level 0; +10 maximum HP for each purchase | Spend 20 scrap per level | Permanently raises subsequent runs' health maximum | More health does not remove the need to avoid attacks |
| Attack-damage upgrade | Level 0; +2 strike damage per purchase | Spend 25 scrap per level | Permanently raises the player's strike damage | Clearly display cost, rank, and resulting damage |
| Movement-speed upgrade | Level 0; +10 units/s per purchase | Spend 20 scrap per level | Permanently raises movement and dodge travel speed | Clamp player movement to 400 units/s maximum |
| Death-run record | No records on a new save; retain at most 3 | Recorded on a death with a bounded movement/attack/dodge action list and run stats | Read as AI input when instantiating the next previous self | Not spendable currency and never consumed; oldest record is replaced when the cap is reached |
| Attack / dodge readiness | Strike cooldown 0.38 s; dash cooldown 1.35 s | Time passing during an active run | Cooldowns gate repeat attacks and evasions | Telegraph enemy wind-ups and show dash feedback; pause freezes the run |

The initial values are provisional balance targets from the source GDD. One death awards 10 points, which is not enough for the cheapest 20-point upgrade; two deaths award 20. A win grants enough for one health or speed upgrade and leaves 10 scrap, or leaves 5 after a damage upgrade.

## 6.2 Progression curve

| Stage | Persistent capability / economy | Challenge |
|---|---|---|
| Fresh save / run 1 | 100 HP, 10 damage, 200 units/s, 0 scrap, 0 purchased levels, 0 records | Movement, two fixed walkers, hazard; no echo yet |
| After one death | +10 scrap; current upgrades unchanged unless purchased | Same deterministic route and encounter; failed run can become an echo |
| After two deaths | Up to 20 accumulated scrap, enough for a health or speed level | One saved echo can be introduced alone; ordinary-enemy count stays limited |
| After a win | +30 scrap before optional spending | A future run can carry upgraded capability and the previous saved echoes |
| Mid progression | Target 1–3 purchased levels; each effect follows its fixed listed increment | Two ordinary threats plus no more than one active echo per arena |
| Later progression | Target 3–5 purchased levels; active record storage remains capped at 3 | Fixed final combination; tune only after measured playtests |

## 6.3 Fairness and randomness

The experience is **asymmetric single-player**: a person directly controls the survivor, and game systems control normal enemies and previous selves. Fairness depends on readable, consistent attack wind-ups; visible hazards; a reachable exit; transparent reward amounts and upgrade costs; a separate first echo encounter; and a bounded final encounter.

| System | Probability | Purpose | Safeguard |
|---|---:|---|---|
| Level and enemy placement | 0% random | Repeatable teaching sequence and test reproduction | Fixed, visible encounter positions |
| Hazard timing and damage | 0% random | Learnable evasion | Visible telegraph, repeated fixed cycle, dodge invulnerability |
| Run reward | 0% random | Predictable economy | A single explicit +30 win or +10 death reward |
| Echo selection | 0% random | Consistent previous-run behavior | Load the most recent valid record; validate and cap saved records |
| Loot, critical hits, and proc effects | None implemented | Avoid unexplained spikes and unwinnable combinations | Add only after explicitly defining probability and testing safety |

# VII. NARRATIVE DESIGN

## 7.1 Premise and setting

A lone survivor tries to escape an enclosed, failing combat facility. When health reaches zero, a later attempt can meet a previous-self echo assembled from the failed run's recorded movement, combat actions, and run statistics. The survivor gains permanent upgrades, but the history of failed runs can also become a future threat. This first level ends at one clearly marked exit; its central theme is that improvement and failure leave evidence in the same place.

## 7.2 Environmental storytelling and diegetic cues

| Implemented detail | What it communicates | Location |
|---|---|---|
| Opened kit and abandoned supplies | Someone previously attempted to prepare or recover | Quiet/recovery room |
| Scratches, damaged cover, and impact marks | The facility has seen repeated fights | Combat rooms and corridors |
| Replayed movement and a familiar visual silhouette | This enemy represents a recorded earlier attempt | Previous-self and conditional final encounters |
| Three bounded stored histories and persistent marks | Repeated attempts accumulate | Between-run save data and repeatable run |
| Warning light/beamed lane and matching warning cue | A hazardous facility system is about to strike | Conduit and exposed shortcut |

The premise is communicated through repeated play, room details, movement, animation, and short original sounds. No long cutscene is needed. The supplied sprites, environment illustrations, and sounds are created in the game or synthesized for the project; no third-party art or audio is included.

## 7.3 Branching and player agency

| Decision | Options and immediate consequence | Convergence |
|---|---|---|
| Damaged-facility route fork | Take the left covered supply route and longer approach; or take the right shortcut and cross one telegraphed beam that can deal 12 HP | Both routes lead to the same basic-combat zone |
| Response to an available previous self | Open with a strike and give the echo visible initial damage; or dash to a more distant starting position without that free hit | Both responses fight the same echo and rejoin the shared final encounter |

These decisions change the immediate risk or starting advantage without requiring branching levels. A fresh save without a death record skips the solo echo and its response choice safely; the rest of the teaching sequence and exit remain available.

# VIII. TECHNICAL DESIGN

## 8.1 Dimension, camera, and input mapping

The game is **2D top-down**, not a 3D or isometric project. Screen-oriented movement, clear silhouettes, telegraphed attacks, and limited mobile screen space favor a stable 2D view. It avoids 3D occlusion, camera collision, and camera-orbit complexity within the course scope.

| Camera element | Configuration and risk control |
|---|---|
| Camera | Camera2D follows the player; position smoothing reduces small movement jitter |
| Bounds | Limits x = 128–896, y = 100–3030 keep the view inside the facility |
| Framing | Portrait 540 × 960 logical viewport; no zoom changes during combat |
| Readability risks | Small devices, touch occlusion, neighboring threats moving off-screen |
| Mitigation | Main threats appear in a narrow vertical corridor; controls stay near screen corners; room labels, health, scrap, warning beam, and enemy silhouettes provide consistent signals |

| Action | Primary input | Alternate input | Rationale |
|---|---|---|---|
| Move | Virtual left touch pad | WASD or arrow keys | Direction remains relative to the screen |
| Strike | Large STRIKE touch button | Space or J | One dependable combat action with visible feedback |
| Dodge / reposition | Large DASH touch button | Shift or K | A separate action supports simultaneous movement and defense |
| Interact with cleared exit | Contextual USE touch button | E or Enter | Only the exit requires interaction |
| Pause / resume | On-screen II button | Escape or P | Mobile and desktop players can safely stop the encounter |

## 8.2 Scene tree and node types

```text
/root
├── AudioManager (Node, autoload)
│   ├── FacilityAmbience (AudioStreamPlayer, generated loop)
│   └── SfxChannel00–07 (AudioStreamPlayer pool)
└── Main (Control, main scene)
    ├── RunManager (Node; persistent stats, rewards and ConfigFile records)
    ├── Level01 (Node2D, instanced for each run)
    │   ├── WorldGeometry (Node2D; generated walls and gates)
    │   ├── Enemies (Node2D; runtime enemy instances)
    │   │   ├── BasicEnemy (CharacterBody2D, instance)
    │   │   └── PreviousSelf (CharacterBody2D, instance when a valid record exists)
    │   ├── Player (CharacterBody2D, instance)
    │   │   ├── CollisionShape2D
    │   │   └── Camera2D
    │   └── HUD (CanvasLayer)
    │       ├── Health, scrap, zone and pause controls (runtime controls)
    │       └── TouchControls (Control; virtual movement and action controls)
    ├── Main menu / workshop screen (runtime CanvasLayer)
    ├── Route / previous-self choice overlay (runtime CanvasLayer)
    └── Pause overlay (runtime CanvasLayer; processes input while paused)
```

## 8.3 Signals and event wiring

| Event / signal | Emitter | Receiver | Result |
|---|---|---|---|
| `health_changed(current, maximum)` | Player | Level/HUD | Update health display and play damage feedback when health falls |
| `attack_performed` | Player | AudioManager | Play generated attack effect; strike resolution damages at most one eligible enemy |
| `dodge_started` | Player | AudioManager | Play generated dodge effect |
| `player_died` | Player | Level01 | End the active run and build its bounded behavior record |
| `defeated(enemy_type)` | BasicEnemy / PreviousSelf | Level01 | Play defeat feedback; the level opens a gate when the last enemy in its fixed arena is gone |
| `choice_requested(choice_kind)` | Level01 | Main | Pause player movement and show one route or echo-response choice |
| `pause_pressed` / `pause_requested` | HUD / Level01 | Main | Pause the scene tree and ambience or resume the active run |
| `level_finished(completed, record)` | Level01 | Main / RunManager | Resolve a single win or death result with its behavior record |
| `run_finished(completed, reward, total_points, recorded_echo)` | RunManager | Main / between-run workshop | Award the exact reward once and present win/loss and upgrade states |
| `attack_pressed`, `dodge_pressed`, `interact_pressed` | TouchControls / HUD | Player / Level01 | Map mobile touches to the same authoritative player actions as InputMap |

The UI displays rewards and upgrade costs but does not decide the authoritative run outcome. The RunManager writes persistent data to Godot's user-specific `user://dead_player_walking.cfg`. Recorded actions and run statistics are kept separate from spendable scrap.

## 8.4 Build verification and honest completion notes

The project is configured for Godot **4.7.1-stable** and its main scene opens at the facility log. The automated Godot integration test checks the actual main scene and exercises keyboard/touch action wiring, pause/resume state, route selection, enemy damage, death reward and record, previous-self introduction, final arena, exit completion, win/loss displays, music initialization, and a permanent upgrade. Run the provided `tests/smoke_test.gd` in a disposable copy using the steps in `README.md`; the test expects a fresh save.

Automated smoke tests verify functional paths, not difficulty balance or perceived fun. No timed human run duration, human PX observations, peer gallery feedback, or paper-economy simulation has been provided. Complete those class activities with actual participants before describing them as measured results. Apply this consolidated content to the official GDD Template 2627A if that template is required for final submission.

## References

Bartle, R. (1996). Hearts, clubs, diamonds, spades: Players who suit MUDs. *Journal of MUD Research, 1*(1).

Csikszentmihalyi, M. (1990). *Flow: The psychology of optimal experience*. Harper & Row.

Hunicke, R., LeBlanc, M., & Zubek, R. (2004). MDA: A formal approach to game design and game research. In *Proceedings of the AAAI Workshop on Challenges in Game AI*.

Studio Tokens. (2026). *Dead Player Walking game design document, Sections I–VIII* [Project design documents].

University of Baguio, School of Information Technology. (2026). *GAMDES1 midterm examination (practical)* [Course assessment rubric].

---

### Post-activity records (complete only after they actually occur)

**Peer gallery walk (Section V).** Feedback received: not supplied. Revision and rationale: not recorded; complete with the actual group activity.  
**Paper simulation / peer playtest (Section VI).** Simulation setup, economy issue, feedback, numeric revision, and rationale: not supplied; complete after actually running and recording the activity.  
**Human playtest (Sections III–V).** No results supplied. Use the observation goals in Section 3.3 and record participant count, build, observations, and resulting revisions.
